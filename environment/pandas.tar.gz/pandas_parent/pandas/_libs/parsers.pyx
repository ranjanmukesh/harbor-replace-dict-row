# Copyright (c) 2012, Lambda Foundry, Inc.
# See LICENSE for the license
from collections import defaultdict
from csv import (
    QUOTE_MINIMAL,
    QUOTE_NONE,
    QUOTE_NONNUMERIC,
)
from datetime import (
    timedelta,
    timezone,
)
import warnings

from pandas._config import (
    is_nan_na,
    using_string_dtype,
)

from pandas.compat.pyarrow import HAS_PYARROW
from pandas.util._exceptions import find_stack_level

from pandas import (
    ArrowDtype,
    StringDtype,
)
from pandas.core.arrays import (
    ArrowExtensionArray,
    ArrowStringArray,
    BooleanArray,
    DatetimeArray,
    FloatingArray,
    IntegerArray,
)

cimport cython
from cpython.bytes cimport (
    PyBytes_AsString,
    PyBytes_AsStringAndSize,
    PyBytes_FromStringAndSize,
)
from cpython.exc cimport (
    PyErr_Fetch,
    PyErr_Occurred,
)
from cpython.long cimport PyLong_FromString
from cpython.object cimport PyObject
from cpython.pycapsule cimport (
    PyCapsule_GetPointer,
    PyCapsule_New,
)
from cpython.ref cimport (
    Py_INCREF,
    Py_XDECREF,
)
from cpython.unicode cimport (
    PyUnicode_AsUTF8String,
    PyUnicode_DecodeUTF8,
)
from cython cimport Py_ssize_t
from libc.stdint cimport (
    INT32_MAX,
    INT64_MAX,
    INT64_MIN,
    int64_t as c_int64_t,
    uintptr_t,
)
from libc.stdlib cimport (
    free,
    malloc,
)
from libc.string cimport (
    memcpy,
    memset,
    strlen,
)

import numpy as np

cimport numpy as cnp
from numpy cimport (
    float64_t,
    int32_t,
    int64_t,
    ndarray,
    uint8_t,
    uint64_t,
)

cnp.import_array()

from pandas._libs cimport util

from pandas._libs import lib

from pandas._libs.khash cimport (
    kh_destroy_float64,
    kh_destroy_str,
    kh_destroy_str_starts,
    kh_destroy_strbox,
    kh_exist_str,
    kh_float64_t,
    kh_get_float64,
    kh_get_str,
    kh_get_str_starts_item,
    kh_get_strbox,
    kh_init_float64,
    kh_init_str,
    kh_init_str_starts,
    kh_init_strbox,
    kh_put_float64,
    kh_put_str,
    kh_put_str_starts_item,
    kh_put_strbox,
    kh_resize_float64,
    kh_resize_str_starts,
    kh_str_starts_t,
    kh_str_t,
    kh_strbox_t,
    kh_strview,
    kh_strview_t,
    khiter_t,
)

from pandas.errors import (
    EmptyDataError,
    ParserError,
    ParserWarning,
)

from pandas.core.dtypes.dtypes import (
    BaseMaskedDtype,
    CategoricalDtype,
    DatetimeTZDtype,
    ExtensionDtype,
)
from pandas.core.dtypes.inference import is_dict_like

from pandas.core.arrays.boolean import BooleanDtype

from pandas._libs.tslibs.dtypes cimport (
    get_supported_reso,
    npy_unit_to_abbrev,
)
from pandas._libs.tslibs.nattype cimport NPY_NAT
from pandas._libs.tslibs.np_datetime cimport (
    NPY_DATETIMEUNIT,
    import_pandas_datetime,
    npy_datetimestruct,
    npy_datetimestruct_to_datetime,
)

import_pandas_datetime()


cdef extern from "pandas/datetime/pd_datetime.h":
    ctypedef enum FormatRequirement:
        PARTIAL_MATCH
        EXACT_MATCH
        INFER_FORMAT

    int parse_iso_8601_datetime(const char *str, int length, int want_exc,
                                npy_datetimestruct *out,
                                NPY_DATETIMEUNIT *out_bestunit,
                                int *out_local, int *out_tzoffset,
                                const char *format, int format_len,
                                FormatRequirement exact) nogil


cdef:
    float64_t INF = <float64_t>np.inf
    float64_t NEGINF = -INF
    int64_t DEFAULT_CHUNKSIZE = 256 * 1024

DEFAULT_BUFFER_HEURISTIC = 2 ** 20


cdef extern from "pandas/parser/tokenizer.h":

    ctypedef enum ParserState:
        START_RECORD
        START_FIELD
        ESCAPED_CHAR
        IN_FIELD
        IN_QUOTED_FIELD
        ESCAPE_IN_QUOTED_FIELD
        QUOTE_IN_QUOTED_FIELD
        EAT_CRNL
        EAT_CRNL_NOP
        EAT_WHITESPACE
        EAT_COMMENT
        EAT_LINE_COMMENT
        WHITESPACE_LINE
        SKIP_LINE
        FINISHED

    enum: ERROR_OVERFLOW, ERROR_INVALID_CHARS

    ctypedef enum BadLineHandleMethod:
        BLHM_ERROR,
        BLHM_WARN,
        BLHM_SKIP

    ctypedef char* (*io_callback)(void *src, size_t nbytes, size_t *bytes_read,
                                  int *status, const char *encoding_errors)
    ctypedef void (*io_cleanup)(void *src)

    ctypedef struct parser_t:
        void *source
        io_callback cb_io
        io_cleanup cb_cleanup

        int64_t chunksize  # Number of bytes to prepare for each chunk
        char *data         # pointer to data to be processed
        int64_t datalen    # amount of data available
        int64_t datapos

        # where to write out tokenized data
        char *stream
        uint64_t stream_len
        uint64_t stream_cap

        # Words NUL-terminated and packed in the stream; word_ends[i] is the
        # stream offset of word i's trailing NUL (word i starts at
        # word_ends[i-1] + 1, or 0 for word 0).
        int64_t *word_ends
        uint64_t words_len
        uint64_t words_cap
        uint64_t max_words_cap   # maximum word cap encountered

        int64_t word_start       # position start of current field

        int64_t *line_start      # position in words for start of line
        int64_t *line_fields     # Number of fields in each line
        uint64_t lines           # Number of lines observed
        uint64_t file_lines      # Number of lines observed (with bad/skipped)
        uint64_t lines_cap       # Vector capacity

        # Tokenizing stuff
        ParserState state
        int doublequote            # is " represented by ""? */
        char delimiter             # field separator */
        int delim_whitespace       # consume tabs / spaces instead
        char quotechar             # quote character */
        char escapechar            # escape character */
        char lineterminator
        int skipinitialspace       # ignore spaces following delimiter? */
        int quoting                # style of quoting to write */

        char commentchar
        int allow_embedded_newline

        int usecols

        Py_ssize_t expected_fields
        BadLineHandleMethod on_bad_lines

        # floating point options
        char decimal
        char sci

        # thousands separator (comma, period)
        char thousands

        int header                  # Boolean: 1: has header, 0: no header
        int64_t header_start        # header row start
        uint64_t header_end         # header row end

        void *skipset
        PyObject *skipfunc
        int64_t skip_first_N_rows
        int64_t skipfooter
        # pick one, depending on whether the converter requires GIL
        double (*double_converter)(const char *, char **,
                                   char, char, char,
                                   int, int *, int *, const char *) noexcept nogil

        #  error handling
        char *warn_msg
        char *error_msg

        int64_t skip_empty_lines

        int preloaded

    ctypedef struct coliter_t:
        const char *stream
        const int64_t *word_ends
        int64_t *line_start
        int64_t col

    ctypedef struct uint_state:
        int seen_sint
        int seen_uint
        int seen_null

    const char *coliter_next(coliter_t *) nogil
    const char *coliter_next_with_idx(coliter_t *, c_int64_t *) nogil

    double precise_xstrtod_with_end(const char *p, char **q, char decimal,
                                    char sci, char tsep, int skip_trailing,
                                    int *error, int *maybe_int,
                                    const char *end) nogil

    int try_parse_plain_double(const char *start, const char *end, char decimal,
                               double *out) nogil

    int infinity_sign(const char *item, int64_t length) nogil

cdef extern from "pandas/parser/pd_parser.h":
    void *new_rd_source(object obj) except NULL

    void del_rd_source(void *src) nogil

    char* buffer_rd_bytes(void *source, size_t nbytes,
                          size_t *bytes_read, int *status, const char *encoding_errors)

    void uint_state_init(uint_state *self)
    int uint64_conflict(uint_state *self)

    void coliter_setup(coliter_t *it, parser_t *parser,
                       int64_t i, int64_t start) nogil

    parser_t* parser_new()

    int parser_init(parser_t *self) nogil
    void parser_free(parser_t *self) nogil
    void parser_del(parser_t *self) nogil
    int parser_add_skiprow(parser_t *self, int64_t row)

    void parser_set_skipfirstnrows(parser_t *self, int64_t nrows)

    void parser_set_default_options(parser_t *self)

    int parser_consume_rows(parser_t *self, uint64_t nrows)

    int parser_trim_buffers(parser_t *self)

    int tokenize_all_rows(parser_t *self, const char *encoding_errors) nogil
    int tokenize_nrows(
        parser_t *self, uint64_t nrows, const char *encoding_errors
    ) nogil

    int64_t str_to_int64(char *p_item, int64_t length, int *error, char tsep) nogil
    uint64_t str_to_uint64(
        uint_state *state, char *p_item, int64_t length, int *error, char tsep
    ) nogil

    double precise_xstrtod(const char *p, char **q, char decimal,
                           char sci, char tsep, int skip_trailing,
                           int *error, int *maybe_int) nogil

    int to_boolean(const char *item, int64_t length, uint8_t *val) nogil

    void PandasParser_IMPORT()

PandasParser_IMPORT

# When not invoked directly but rather assigned as a function,
# cdef extern'ed declarations seem to leave behind an undefined symbol
cdef double precise_xstrtod_wrapper(const char *p, char **q, char decimal,
                                    char sci, char tsep, int skip_trailing,
                                    int *error, int *maybe_int,
                                    const char *end) noexcept nogil:
    return precise_xstrtod_with_end(p, q, decimal, sci, tsep, skip_trailing,
                                    error, maybe_int, end)


cdef char* buffer_rd_bytes_wrapper(void *source, size_t nbytes,
                                   size_t *bytes_read, int *status,
                                   const char *encoding_errors) noexcept:
    return buffer_rd_bytes(source, nbytes, bytes_read, status, encoding_errors)

cdef void del_rd_source_wrapper(void *src) noexcept nogil:
    del_rd_source(src)


cdef class TextReader:
    """

    # source: StringIO or file object

    """

    cdef:
        parser_t *parser
        object na_fvalues
        list true_values, false_values
        object handle
        object orig_header
        bint na_filter, keep_default_na, has_usecols, has_mi_columns
        bint allow_leading_cols
        # Trim the parser's buffers after a whole-file read.  The parallel
        # reader turns this off on its workers, whose buffers are reused
        # across chunks and freed at close.
        public bint trim_after_read
        # When not None, ParserWarnings are appended here as
        # (message, category) instead of being raised.  The parallel reader
        # gives every worker the same sink so a warning is raised once rather
        # than once per chunk (GH#66259).
        public object warning_sink
        uint64_t parser_start  # this is modified after __init__
        const char *encoding_errors
        object _encoding_errors
        kh_str_starts_t *false_set
        kh_str_starts_t *true_set
        int64_t buffer_lines, skipfooter
        list dtype_cast_order  # list[np.dtype]
        list names   # can be None
        set noconvert  # set[int]
        dict datetime_cols  # dict[int, bool]
        dict dt_chunk_states  # dict[int, _DatetimeChunkState] | None
        int64_t lm_chunk_idx
        object _buffer_ref  # keeps pre-loaded bytes alive during parse
        str _pa_target  # cached _string_convert target; None = unresolved
        # Let the pyarrow string fast path return raw _PendingStringColumn
        # handles instead of ExtensionArrays; the c_parser_wrapper layer
        # materializes them once per column at the end of the read.
        public bint defer_pa_wrap
        # Set by _close, which frees the tokenizer's buffers.  Reading from a
        # closed reader would dereference those freed pointers (GH#66622).
        bint is_closed

    cdef public:
        int64_t leading_cols, table_width
        object delimiter  # bytes or str
        object converters
        object na_values  # dict[hashable, set[str]] | list[str]
        list header  # list[list[non-negative integers]]
        object index_col
        object skiprows
        object dtype
        object usecols
        set unnamed_cols  # set[str]
        str dtype_backend

    def __cinit__(self, source,
                  delimiter=b",",  # bytes | str
                  header=0,
                  int64_t header_start=0,
                  uint64_t header_end=0,
                  index_col=None,
                  names=None,
                  tokenize_chunksize=DEFAULT_CHUNKSIZE,
                  bint delim_whitespace=False,
                  converters=None,
                  bint skipinitialspace=False,
                  escapechar=None,      # bytes | str
                  bint doublequote=True,
                  quotechar=b'"',
                  quoting=0,            # int
                  lineterminator=None,  # bytes | str
                  comment=None,
                  decimal=b".",         # bytes | str
                  thousands=None,       # bytes | str
                  dtype=None,
                  usecols=None,
                  on_bad_lines=BLHM_ERROR,
                  bint na_filter=True,
                  na_values=None,       # dict[hashable, set[str]] | set[str]
                  na_fvalues=None,      # dict[hashable, set[float]] | set[float]
                  bint keep_default_na=True,
                  true_values=None,
                  false_values=None,
                  bint allow_leading_cols=True,
                  skiprows=None,
                  skipfooter=0,         # int64_t
                  float_precision=None,
                  bint skip_blank_lines=True,
                  encoding_errors=b"strict",
                  dtype_backend="numpy"):

        # set encoding for native Python and C library
        if isinstance(encoding_errors, str):
            encoding_errors = encoding_errors.encode("utf-8")
        elif encoding_errors is None:
            encoding_errors = b"strict"
        # store encoding_errors in `self` for Cython to manage its lifetime.
        self._encoding_errors = encoding_errors
        self.encoding_errors = PyBytes_AsString(encoding_errors)

        self.parser = parser_new()
        self.parser.chunksize = tokenize_chunksize

        self.parser.usecols = (usecols is not None)

        self._setup_parser_source(source)
        parser_set_default_options(self.parser)

        parser_init(self.parser)

        if delim_whitespace:
            self.parser.delim_whitespace = delim_whitespace
        else:
            if len(delimiter) > 1:
                raise ValueError("only length-1 separators excluded right now")
            self.parser.delimiter = <char>ord(delimiter)

        # ----------------------------------------
        # parser options

        self.parser.doublequote = doublequote
        self.parser.skipinitialspace = skipinitialspace
        self.parser.skip_empty_lines = skip_blank_lines

        if lineterminator is not None:
            if len(lineterminator) != 1:
                raise ValueError("Only length-1 line terminators supported")
            self.parser.lineterminator = <char>ord(lineterminator)

        if len(decimal) != 1:
            raise ValueError("Only length-1 decimal markers supported")
        self.parser.decimal = <char>ord(decimal)

        if thousands is not None:
            if len(thousands) != 1:
                raise ValueError("Only length-1 thousands markers supported")
            self.parser.thousands = <char>ord(thousands)

        if escapechar is not None:
            if len(escapechar) != 1:
                raise ValueError("Only length-1 escapes supported")
            self.parser.escapechar = <char>ord(escapechar)

        self._set_quoting(quotechar, quoting)

        dtype_order = ["int64", "float64", "bool", "object"]
        if quoting == QUOTE_NONNUMERIC:
            # consistent with csv module semantics, cast all to float
            dtype_order = dtype_order[1:]
        self.dtype_cast_order = [np.dtype(x) for x in dtype_order]

        if comment is not None:
            if len(comment) > 1:
                raise ValueError("Only length-1 comment characters supported")
            self.parser.commentchar = <char>ord(comment)

        self.parser.on_bad_lines = on_bad_lines

        self.skiprows = skiprows
        if skiprows is not None:
            self._make_skiprow_set()

        self.skipfooter = skipfooter

        if usecols is not None:
            self.has_usecols = 1
            # GH-20558, validate usecols at higher level and only pass clean
            # usecols into TextReader.
            self.usecols = usecols

        if skipfooter > 0:
            self.parser.on_bad_lines = BLHM_SKIP

        self.delimiter = delimiter

        # na_fvalues is created from user-provided na_value in _clean_na_values
        #  which ensures that either
        #  a) na_values is set[str] and na_fvalues is set[float]
        #  b) na_values is dict[Hashable, set[str]] and
        #     na_fvalues is dict[Hashable, set[float]]
        #     (tests for this case are in test_na_values.py)
        if not isinstance(na_values, dict):
            # i.e. it must be a set
            na_values = list(na_values)

        self.na_values = na_values
        self.na_fvalues = na_fvalues

        self.true_values = _maybe_encode(true_values) + _true_values
        self.false_values = _maybe_encode(false_values) + _false_values

        self.true_set = kset_from_list(self.true_values)
        self.false_set = kset_from_list(self.false_values)

        self.keep_default_na = keep_default_na
        self.converters = converters
        self.na_filter = na_filter
        self.defer_pa_wrap = False
        self._pa_target = None
        self.trim_after_read = True
        self.warning_sink = None

        if float_precision in ("round_trip", "legacy", "high", None):
            self.parser.double_converter = precise_xstrtod_wrapper
        else:
            raise ValueError(f"Unrecognized float_precision option: "
                             f"{float_precision}")

        # Caller is responsible for ensuring we have one of
        # - None
        # - DtypeObj
        # - dict[Any, DtypeObj]
        self.dtype = dtype
        self.dtype_backend = dtype_backend

        self.noconvert = set()
        self.datetime_cols = {}
        self.dt_chunk_states = None
        self.lm_chunk_idx = 0

        self.index_col = index_col

        # ----------------------------------------
        # header stuff

        self.allow_leading_cols = allow_leading_cols
        self.leading_cols = 0  # updated in _get_header

        # TODO: no header vs. header is not the first row
        self.has_mi_columns = 0
        self.orig_header = header
        if header is None:
            # sentinel value
            self.parser.header_start = -1
            self.parser.header_end = -1
            self.parser.header = -1
            self.parser_start = 0
            prelim_header = []
        else:
            if isinstance(header, list):
                if len(header) > 1:
                    # need to artificially skip the final line
                    # which is still a header line
                    header = list(header)
                    header.append(header[-1] + 1)
                    self.parser.header_end = header[-1]
                    self.has_mi_columns = 1
                else:
                    self.parser.header_end = header[0]

                self.parser_start = header[-1] + 1
                self.parser.header_start = header[0]
                self.parser.header = header[0]
                prelim_header = header
            else:
                self.parser.header_start = header
                self.parser.header_end = header
                self.parser_start = header + 1
                self.parser.header = header
                prelim_header = [header]

        self.names = names
        header, table_width, unnamed_cols = self._get_header(prelim_header)
        # header, table_width, and unnamed_cols are set here, never changed
        self.header = header
        self.table_width = table_width
        self.unnamed_cols = unnamed_cols

        if not self.table_width:
            raise EmptyDataError("No columns to parse from file")

        # Compute buffer_lines as function of table width.
        heuristic = DEFAULT_BUFFER_HEURISTIC // self.table_width
        self.buffer_lines = 1
        while self.buffer_lines * 2 < heuristic:
            self.buffer_lines *= 2

    def __init__(self, *args, **kwargs):
        pass

    def __dealloc__(self):
        _close(self)
        parser_del(self.parser)

    def close(self):
        _close(self)

    cdef _check_not_closed(self):
        if self.is_closed:
            raise ValueError("I/O operation on closed file.")

    def load_buffer(self, const unsigned char[::1] data, bint strip_bom=False):
        """Pre-load all chunk bytes into the parser's internal buffer.

        After this call the tokeniser reads directly from the supplied *data*
        buffer rather than calling back into Python via the ``cb_io``
        I/O callback.  Because ``_tokenize_helper`` in ``tokenizer.cpp`` checks
        ``self->source == NULL`` before invoking ``parser_buffer_bytes``, the
        GIL is **never** re-acquired during tokenisation — enabling true CPU
        parallelism across threads.

        Call this method immediately after constructing a ``TextReader`` with
        ``header=None`` (and before calling ``read()``).

        Parameters
        ----------
        data : contiguous buffer
            Raw CSV bytes for one chunk (no header line).  Accepts any object
            implementing the buffer protocol (bytes, memoryview, mmap, etc.).
        strip_bom : bool, default False
            Skip a leading UTF-8 byte-order mark.  Pass True only when *data*
            starts at byte 0 of the underlying file; a BOM byte sequence
            anywhere else is real data and is preserved.
        """
        # Release the rd_source that was allocated for the dummy source passed
        # to __cinit__, balancing the Py_INCREF done by new_rd_source.
        if self.parser.cb_cleanup != NULL:
            self.parser.cb_cleanup(self.parser.source)
            self.parser.cb_cleanup = NULL

        # NULL source is the sentinel checked in _tokenize_helper to skip the
        # Python I/O callback once the pre-loaded buffer is exhausted.
        self.parser.source = NULL

        # Keep the underlying Python object alive for the full duration of the
        # parse so that parser.data (which points into it) remains valid.
        self._buffer_ref = data.base
        self.parser.data = <char *>&data[0]
        self.parser.datalen = data.shape[0]
        self.parser.datapos = 0

        # Disable the header/first-line special cases in tokenizer.cpp: the
        # buffer holds plain data rows, so its first line must get regular
        # bad-line handling and no BOM stripping (see parser_t.preloaded).
        self.parser.preloaded = 1
        if (
            strip_bom
            and data.shape[0] >= 3
            and data[0] == 0xEF
            and data[1] == 0xBB
            and data[2] == 0xBF
        ):
            self.parser.datapos = 3

        # _get_header may have set state=FINISHED when it probed the empty
        # dummy source during __cinit__; reset so tokenisation actually runs.
        self.parser.state = START_RECORD

    def _set_quoting(self, quote_char: str | bytes | None, quoting: int):
        if not isinstance(quoting, int):
            raise TypeError('"quoting" must be an integer')

        if not QUOTE_MINIMAL <= quoting <= QUOTE_NONE:
            raise TypeError('bad "quoting" value')

        if not isinstance(quote_char, (str, bytes)) and quote_char is not None:
            dtype = type(quote_char).__name__
            raise TypeError(f'"quotechar" must be string, not {dtype}')

        if quote_char is None or quote_char == "":
            if quoting != QUOTE_NONE:
                raise TypeError("quotechar must be set if quoting enabled")
            self.parser.quoting = quoting
            self.parser.quotechar = -1
        elif len(quote_char) > 1:  # 0-len case handled earlier
            raise TypeError('"quotechar" must be a 1-character string')
        else:
            self.parser.quoting = quoting
            self.parser.quotechar = <char>ord(quote_char)

    cdef _make_skiprow_set(self):
        if util.is_integer_object(self.skiprows):
            parser_set_skipfirstnrows(self.parser, self.skiprows)
        elif not callable(self.skiprows):
            for i in self.skiprows:
                parser_add_skiprow(self.parser, i)
        else:
            self.parser.skipfunc = <PyObject *>self.skiprows

    cdef _setup_parser_source(self, source):
        cdef:
            void *ptr

        ptr = new_rd_source(source)
        self.parser.source = ptr
        self.parser.cb_io = buffer_rd_bytes_wrapper
        self.parser.cb_cleanup = del_rd_source_wrapper

    cdef _get_header(self, list prelim_header):
        # header is now a list of lists, so field_count should use header[0]
        #
        # modifies:
        #   self.parser attributes
        #   self.parser_start
        #   self.leading_cols

        cdef:
            Py_ssize_t i, start, field_count, passed_count, unnamed_count, level
            const char *word
            str name
            uint64_t hr, data_line = 0
            list header = []
            set unnamed_cols = set()

        if self.parser.header_start >= 0:

            # Header is in the file
            for level, hr in enumerate(prelim_header):

                this_header = []

                if self.parser.lines < hr + 1:
                    self._tokenize_rows(hr + 2)

                if self.parser.lines == 0:
                    field_count = 0
                    start = self.parser.line_start[0]

                # e.g., if header=3 and file only has 2 lines
                elif (self.parser.lines < hr + 1
                      and not isinstance(self.orig_header, list)) or (
                          self.parser.lines < hr):
                    msg = self.orig_header
                    if isinstance(msg, list):
                        joined = ",".join(str(m) for m in msg)
                        msg = f"[{joined}], len of {len(msg)},"
                    raise ParserError(
                        f"Passed header={msg} but only "
                        f"{self.parser.lines} lines in file")

                else:
                    field_count = self.parser.line_fields[hr]
                    start = self.parser.line_start[hr]

                unnamed_count = 0
                unnamed_col_indices = []

                for i in range(field_count):
                    word = _parser_word(self.parser, start + i)

                    # _token_len, not strlen: a column name containing an
                    # embedded NUL must not be truncated at it.
                    name = PyUnicode_DecodeUTF8(
                        word, _token_len(self.parser, start + i),
                        self.encoding_errors)

                    if name == "":
                        if self.has_mi_columns:
                            name = f"Unnamed: {i}_level_{level}"
                        else:
                            name = f"Unnamed: {i}"

                        unnamed_count += 1
                        unnamed_col_indices.append(i)

                    this_header.append(name)

                if not self.has_mi_columns:
                    # Ensure that regular columns are used before unnamed ones
                    # to keep given names and mangle unnamed columns
                    col_loop_order = [i for i in range(len(this_header))
                                      if i not in unnamed_col_indices
                                      ] + unnamed_col_indices
                    counts = {}

                    for i in col_loop_order:
                        col = this_header[i]
                        old_col = col
                        cur_count = counts.get(col, 0)

                        if cur_count > 0:
                            while cur_count > 0:
                                counts[old_col] = cur_count + 1
                                col = f"{old_col}.{cur_count}"
                                if col in this_header:
                                    cur_count += 1
                                else:
                                    cur_count = counts.get(col, 0)

                            if (
                                self.dtype is not None
                                and is_dict_like(self.dtype)
                                and self.dtype.get(old_col) is not None
                                and self.dtype.get(col) is None
                            ):
                                self.dtype.update({col: self.dtype.get(old_col)})

                        this_header[i] = col
                        counts[col] = cur_count + 1

                if self.has_mi_columns:

                    # If we have grabbed an extra line, but it's not in our
                    # format, save in the buffer, and create a blank extra
                    # line for the rest of the parsing code.
                    if hr == prelim_header[-1]:
                        lc = len(this_header)
                        ic = (len(self.index_col) if self.index_col
                              is not None else 0)

                        # if wrong number of blanks or no index, not our format
                        if (lc != unnamed_count and lc - ic > unnamed_count) or ic == 0:
                            hr -= 1
                            self.parser_start -= 1
                            this_header = [None] * lc

                data_line = hr + 1
                header.append(this_header)
                unnamed_cols.update({this_header[i] for i in unnamed_col_indices})

            if self.names is not None:
                header = [self.names]

        elif self.names is not None:
            # Names passed
            if self.parser.lines < 1:
                if not self.has_usecols:
                    self.parser.expected_fields = len(self.names)
                self._tokenize_rows(1)

            header = [self.names]

            if self.parser.lines < 1:
                field_count = len(header[0])
            else:
                field_count = self.parser.line_fields[data_line]

            # Enforce this unless usecols
            if not self.has_usecols:
                self.parser.expected_fields = max(field_count, len(self.names))

        else:
            # No header passed nor to be found in the file
            if self.parser.lines < 1:
                self._tokenize_rows(1)

            return None, self.parser.line_fields[0], unnamed_cols

        # Corner case, not enough lines in the file
        if self.parser.lines < data_line + 1:
            field_count = len(header[0])
        else:

            field_count = self.parser.line_fields[data_line]

            # #2981
            if self.names is not None:
                field_count = max(field_count, len(self.names))

            passed_count = len(header[0])

            if (self.has_usecols and self.allow_leading_cols and
                    not callable(self.usecols)):
                nuse = len(self.usecols)
                if nuse == passed_count:
                    self.leading_cols = 0
                elif self.names is None and nuse < passed_count:
                    self.leading_cols = field_count - passed_count
                elif passed_count != field_count:
                    raise ValueError("Number of passed names did not match number of "
                                     "header fields in the file")
            # oh boy, #2442, #2981
            elif self.allow_leading_cols and passed_count < field_count:
                self.leading_cols = field_count - passed_count

        return header, field_count, unnamed_cols

    def read(self, rows: int | None = None) -> dict[int, "ArrayLike"]:
        """
        rows=None --> read all rows
        """
        self._check_not_closed()
        # Don't care about memory usage
        columns = self._read_rows(rows, self.trim_after_read)

        return columns

    def read_low_memory(self, rows: int | None)-> list[dict[int, "ArrayLike"]]:
        """
        rows=None --> read all rows
        """
        # Conserve intermediate space
        # Caller is responsible for concatenating chunks,
        #  see c_parser_wrapper._concatenate_chunks
        cdef:
            size_t rows_read = 0
            list chunks = []

        self._check_not_closed()

        if self.datetime_cols:
            # Per-chunk fastpath state keyed by column; see _DatetimeChunkState.
            self.dt_chunk_states = {}

        try:
            if rows is None:
                while True:
                    try:
                        self.lm_chunk_idx = len(chunks)
                        chunk = self._read_rows(self.buffer_lines, 0)
                        if len(chunk) == 0:
                            break
                    except StopIteration:
                        break
                    else:
                        chunks.append(chunk)
            else:
                while rows_read < rows:
                    try:
                        crows = min(self.buffer_lines, rows - rows_read)

                        self.lm_chunk_idx = len(chunks)
                        chunk = self._read_rows(crows, 0)
                        if len(chunk) == 0:
                            break

                        rows_read += len(list(chunk.values())[0])
                    except StopIteration:
                        break
                    else:
                        chunks.append(chunk)

            parser_trim_buffers(self.parser)

            if len(chunks) == 0:
                raise StopIteration

            self._finalize_datetime_chunks(chunks)
            return chunks
        finally:
            self.dt_chunk_states = None

    cdef _finalize_datetime_chunks(self, list chunks):
        """
        For parse_dates fastpath columns where a chunk fell back to strings,
        rebuild the already-converted chunks' object-string arrays from their
        raw-byte receipts so the column is all-or-nothing, exactly like a
        non-chunked read.
        """
        cdef _DatetimeChunkState state

        if self.dt_chunk_states is None:
            return
        for col, state in self.dt_chunk_states.items():
            if not state.failed:
                continue
            for chunk_idx, arena, offsets, use_dtype_backend in state.receipts:
                strs = _box_arena_utf8(arena, offsets, self.encoding_errors)
                if use_dtype_backend:
                    strs = _maybe_upcast(
                        strs,
                        use_dtype_backend=True,
                        dtype_backend=self.dtype_backend,
                    )
                chunks[chunk_idx][col] = strs

    cdef _tokenize_rows(self, uint64_t nrows):
        cdef:
            int status

        with nogil:
            status = tokenize_nrows(self.parser, nrows, self.encoding_errors)

        self._check_tokenize_status(status)

    cdef _warn_parser(self, object msg):
        if self.warning_sink is not None:
            self.warning_sink.append((msg, ParserWarning))
        else:
            warnings.warn(msg, ParserWarning, stacklevel=find_stack_level())

    cdef _check_tokenize_status(self, int status):
        if self.parser.warn_msg != NULL:
            self._warn_parser(
                PyUnicode_DecodeUTF8(
                    self.parser.warn_msg,
                    strlen(self.parser.warn_msg),
                    self.encoding_errors
                )
            )
            free(self.parser.warn_msg)
            self.parser.warn_msg = NULL

        if status < 0:
            raise_parser_error("Error tokenizing data", self.parser)

    #  -> dict[int, "ArrayLike"]
    cdef _read_rows(self, rows, bint trim):
        cdef:
            int64_t buffered_lines
            int64_t irows

        if rows is not None:
            irows = rows
            buffered_lines = self.parser.lines - self.parser_start
            if buffered_lines < irows:
                self._tokenize_rows(irows - buffered_lines)

            if self.skipfooter > 0:
                raise ValueError("skipfooter can only be used to read "
                                 "the whole file")
        else:
            with nogil:
                status = tokenize_all_rows(self.parser, self.encoding_errors)

            self._check_tokenize_status(status)

        if self.parser_start >= self.parser.lines:
            raise StopIteration

        columns = self._convert_column_data(rows)
        if len(columns) > 0:
            rows_read = len(list(columns.values())[0])
            # trim
            parser_consume_rows(self.parser, rows_read)
            if trim:
                parser_trim_buffers(self.parser)
            self.parser_start -= rows_read

        return columns

    def set_noconvert(self, i: int) -> None:
        self.noconvert.add(i)

    def remove_noconvert(self, i: int) -> None:
        self.noconvert.remove(i)

    def set_datetime_convert(
        self, i: int, require_consistent_format: bool = True
    ) -> None:
        self.datetime_cols[i] = require_consistent_format

    def _convert_column_data(self, rows: int | None) -> dict[int, "ArrayLike"]:
        cdef:
            int64_t i
            int nused
            kh_str_starts_t *na_hashset = NULL
            int64_t start, end
            object name, col_dtype = None
            set na_fset
            bint na_filter = 0
            int64_t num_cols
            dict results
            bint is_default_dict_dtype

        start = self.parser_start

        if rows is None:
            end = self.parser.lines
        else:
            end = min(start + rows, self.parser.lines)

        num_cols = -1
        for i in range(<int64_t>self.parser.lines):
            num_cols = (num_cols < self.parser.line_fields[i]) * \
                self.parser.line_fields[i] + \
                (num_cols >= self.parser.line_fields[i]) * num_cols

        self._validate_usecols_and_names(num_cols)

        results = {}
        nused = 0
        is_default_dict_dtype = isinstance(self.dtype, defaultdict)

        for i in range(self.table_width):
            if i < self.leading_cols:
                # Pass through leading columns always
                name = i
            elif (self.usecols and not callable(self.usecols) and
                    nused == len(self.usecols)):
                # Once we've gathered all requested columns, stop. GH5766
                break
            else:
                name = self._get_column_name(i, nused)
                usecols = set()
                if callable(self.usecols):
                    if self.usecols(name):
                        usecols = {i}
                else:
                    usecols = self.usecols
                if self.has_usecols and not (i in usecols or
                                             name in usecols):
                    continue
                nused += 1

            conv = self._get_converter(i, name)
            col_dtype = self._get_col_dtype(i, is_default_dict_dtype, name)

            if conv:
                if col_dtype is not None:
                    self._warn_parser(f"Both a converter and dtype were specified "
                                      f"for column {name} - only the converter will "
                                      f"be used.")
                results[i] = _apply_converter(conv, self.parser, i, start, end)
                continue

            # Collect the set of NaN values associated with the column.
            # If we aren't supposed to do that, or none are collected,
            # we set `na_filter` to `0` (`1` otherwise).
            na_fset = set()

            if self.na_filter:
                na_list, na_fset = self._get_na_list(i, name)
                na_filter = 1
                na_hashset = kset_from_list(na_list)
            else:
                na_filter = 0

            # Attempt to parse tokens and infer dtype of the column.
            # Should return as the desired dtype (inferred or specified).
            try:
                col_res, na_count = self._convert_tokens(
                    i, start, end, name, na_filter, na_hashset,
                    na_fset, col_dtype)
            finally:
                # gh-21353
                #
                # Cleanup the NaN hash that we generated
                # to avoid memory leaks.
                if na_filter:
                    self._free_na_set(na_hashset)

            # don't try to upcast EAs
            if (
                na_count > 0 and not isinstance(col_dtype, ExtensionDtype)
                or self.dtype_backend != "numpy"
            ):
                use_dtype_backend = self.dtype_backend != "numpy" and col_dtype is None
                col_res = _maybe_upcast(
                    col_res,
                    use_dtype_backend=use_dtype_backend,
                    dtype_backend=self.dtype_backend,
                )

            if col_res is None:
                raise ParserError(f"Unable to parse column {i}")

            results[i] = col_res

        self.parser_start += end - start

        return results

    # -> tuple["ArrayLike", int]:
    cdef _convert_tokens(self, Py_ssize_t i, int64_t start,
                         int64_t end, object name, bint na_filter,
                         kh_str_starts_t *na_hashset,
                         set na_fset, object col_dtype):

        if col_dtype is not None:
            col_res, na_count = self._convert_with_dtype(
                col_dtype, i, start, end, na_filter,
                1, na_hashset, na_fset, False)

            # Fallback on the parse (e.g. we requested int dtype,
            # but its actually a float).
            if col_res is not None:
                return col_res, na_count

        if i in self.noconvert:
            if i in self.datetime_cols:
                # Try direct char-buffer -> datetime64 fastpath; fall back to
                # object-strings if the input isn't ISO8601 (handled downstream
                # by date_converter via to_datetime).
                state = None
                if self.dt_chunk_states is not None:
                    state = self.dt_chunk_states.get(i)
                    if state is None:
                        state = _DatetimeChunkState()
                        self.dt_chunk_states[i] = state
                if state is None or not state.failed:
                    col_res, na_count = _datetime_box_utf8(
                        self.parser, i, start, end, na_filter, na_hashset,
                        self.datetime_cols[i], state, self.lm_chunk_idx,
                        self.dtype_backend != "numpy" and col_dtype is None)
                    if col_res is not None:
                        return col_res, na_count
                    if state is not None:
                        state.failed = True
            return self._string_convert(i, start, end, na_filter, na_hashset)
        else:
            col_res = None
            maybe_int = True
            for dt in self.dtype_cast_order:
                if not maybe_int and dt.kind in "iu":
                    continue

                if dt == object:
                    # Last fallback in the cast order: route directly through
                    # _string_convert so the pyarrow fast path can fire when
                    # allow_pyarrow applies (col_dtype is None). Bypass
                    # _convert_with_dtype to avoid its default allow_pyarrow=False.
                    col_res, na_count = self._string_convert(
                        i, start, end, na_filter, na_hashset,
                        allow_pyarrow=col_dtype is None)
                    break

                try:
                    col_res, na_count = self._convert_with_dtype(
                        dt, i, start, end, na_filter, 0, na_hashset, na_fset, True)
                except ValueError as e:
                    if str(e) == "Number is not int":
                        maybe_int = False
                        continue
                    else:
                        # This error is raised from trying to convert to uint64,
                        # and we discover that we cannot convert to any numerical
                        # dtype successfully. As a result, we leave the data
                        # column AS IS with object dtype.
                        col_res, na_count = self._string_convert(
                            i, start, end, 0, na_hashset,
                            allow_pyarrow=col_dtype is None)
                except OverflowError:
                    try:
                        col_res, na_count = _try_pylong(self.parser, i, start,
                                                        end, na_filter, na_hashset)
                    except ValueError:
                        col_res, na_count = self._string_convert(
                            i, start, end, 0, na_hashset,
                            allow_pyarrow=col_dtype is None)

                if col_res is not None:
                    break

        # we had a fallback parse on the dtype, so now try to cast
        if col_res is not None and col_dtype is not None:
            # If col_res is bool, it might actually be a bool array mixed with NaNs
            # (see _try_bool_flex()). Usually this would be taken care of using
            # _maybe_upcast(), but if col_dtype is a floating type we should just
            # take care of that cast here.
            if col_res.dtype == np.bool_ and col_dtype.kind == "f":
                mask = col_res.view(np.uint8) == na_values[np.uint8]
                col_res = col_res.astype(col_dtype)
                np.putmask(col_res, mask, np.nan)
                return col_res, na_count

            # NaNs are already cast to True here, so can not use astype
            if col_res.dtype == np.bool_ and col_dtype.kind in "iu":
                if na_count > 0:
                    raise ValueError(
                        f"cannot safely convert passed user dtype of "
                        f"{col_dtype} for {np.bool_} dtyped data in "
                        f"column {i} due to NA values"
                    )

            # only allow safe casts, eg. with a nan you cannot safely cast to int
            try:
                col_res = col_res.astype(col_dtype, casting="safe")
            except TypeError:

                # float -> int conversions can fail the above
                # even with no nans
                col_res_orig = col_res
                col_res = col_res.astype(col_dtype)
                if (col_res != col_res_orig).any():
                    raise ValueError(
                        f"cannot safely convert passed user dtype of "
                        f"{col_dtype} for {col_res_orig.dtype.name} dtyped data in "
                        f"column {i}")

        return col_res, na_count

    cdef _convert_with_dtype(self, object dtype, Py_ssize_t i,
                             int64_t start, int64_t end,
                             bint na_filter,
                             bint user_dtype,
                             kh_str_starts_t *na_hashset,
                             set na_fset, bint raise_on_invalid):
        if isinstance(dtype, CategoricalDtype):
            # TODO: I suspect that _categorical_convert could be
            # optimized when dtype is an instance of CategoricalDtype
            codes, cats, na_count = _categorical_convert(
                self.parser, i, start, end, na_filter, na_hashset,
                self.encoding_errors)

            # Method accepts list of strings, not encoded ones.
            true_values = [x.decode() for x in self.true_values]
            array_type = dtype.construct_array_type()
            cat = array_type._from_inferred_categories(
                cats, codes, dtype, true_values=true_values)
            return cat, na_count

        elif isinstance(dtype, ExtensionDtype):
            if isinstance(dtype, BaseMaskedDtype) and dtype.kind in "iuf":
                # Fast path for nullable Integer/Floating dtypes: parse straight
                # from the C buffers via the nogil numeric converters, instead
                # of materializing an intermediate ndarray[object] of strings
                # and re-parsing it through to_numeric in
                # _from_sequence_of_strings.
                masked = self._convert_masked_numeric(
                    dtype, i, start, end, na_filter, na_hashset, na_fset)
                if masked is not None:
                    return masked
                # Not confidently numeric-parseable (e.g. values that overflow
                # uint64, or non-numeric data); fall through to the generic
                # _from_sequence_of_strings path, which handles it identically
                # to before.
            elif isinstance(dtype, BooleanDtype):
                # Fast path for the nullable boolean dtype.
                boolean = self._convert_boolean_masked(
                    i, start, end, na_filter, na_hashset)
                if boolean is not None:
                    return boolean
                # An unrecognized token spelling; fall through to the generic
                # path (which raises the canonical error, or applies
                # user-supplied none_values).
            elif (isinstance(dtype, ArrowDtype)
                    and HAS_PYARROW
                    and self.encoding_errors == b"strict"):
                # Fast path for pyarrow-backed dtypes: build a pyarrow
                # large_string array from the C buffers (nogil) and convert it
                # with pyarrow compute, instead of materializing an
                # ndarray[object] and re-parsing via to_numeric / to_datetime.
                arrow = self._convert_arrow(dtype, i, start, end,
                                            na_filter, na_hashset, na_fset)
                if arrow is not None:
                    return arrow
                # Invalid UTF-8 or a conversion pyarrow could not perform;
                # fall through to the generic path for identical behavior.

            result, na_count = self._string_convert(i, start, end, na_filter,
                                                    na_hashset)

            array_type = dtype.construct_array_type()
            try:
                # use _from_sequence_of_strings if the class defines it
                if isinstance(dtype, BooleanDtype):
                    # xref GH 47534: BooleanArray._from_sequence_of_strings has extra
                    # kwargs
                    true_values = [x.decode() for x in self.true_values]
                    false_values = [x.decode() for x in self.false_values]
                    result = array_type._from_sequence_of_strings(
                        result, dtype=dtype, true_values=true_values,
                        false_values=false_values)
                else:
                    result = array_type._from_sequence_of_strings(result, dtype=dtype)
            except NotImplementedError:
                raise NotImplementedError(
                    f"Extension Array: {array_type} must implement "
                    f"_from_sequence_of_strings in order "
                    f"to be used in parser methods")

            return result, na_count

        elif dtype.kind in "iu":
            try:
                result, na_count = _try_int64(self.parser, i, start, end,
                                              na_filter, na_hashset, raise_on_invalid)
                if user_dtype and na_count is not None:
                    if na_count > 0:
                        raise ValueError(f"Integer column has NA values in column {i}")
            except OverflowError:
                result = _try_uint64(self.parser, i, start, end,
                                     na_filter, na_hashset, raise_on_invalid)
                na_count = 0

            if result is not None and dtype != "int64":
                result = result.astype(dtype)

            return result, na_count

        elif dtype.kind == "f":
            result, na_count = _try_double(self.parser, i, start, end,
                                           na_filter, na_hashset, na_fset)

            if result is not None and dtype != "float64":
                result = result.astype(dtype)
            return result, na_count
        elif dtype.kind == "c":
            # GH#9379 numpy parses both "1+2j" and "(1+2j)" forms; the
            # latter is what to_csv writes for complex columns.
            result, na_count = self._string_convert(i, start, end, na_filter,
                                                    na_hashset)
            return np.asarray(result, dtype=dtype), na_count
        elif dtype.kind == "b":
            result, na_count = _try_bool_flex(self.parser, i, start, end,
                                              na_filter, na_hashset,
                                              self.true_set, self.false_set)
            if user_dtype and na_count is not None:
                if na_count > 0:
                    raise ValueError(f"Bool column has NA values in column {i}")
            return result, na_count

        elif dtype.kind == "S":
            # TODO: na handling
            width = dtype.itemsize
            if width > 0:
                result = _to_fw_string(self.parser, i, start, end, width)
                return result, 0

            # treat as a regular string parsing
            return self._string_convert(i, start, end, na_filter,
                                        na_hashset)
        elif dtype.kind == "U":
            width = dtype.itemsize
            if width > 0:
                raise TypeError(f"the dtype {dtype} is not supported for parsing")

            # unicode variable width
            return self._string_convert(i, start, end, na_filter,
                                        na_hashset)
        elif dtype == object:
            return self._string_convert(i, start, end, na_filter,
                                        na_hashset)
        elif dtype.kind == "M":
            raise TypeError(f"the dtype {dtype} is not supported "
                            f"for parsing, pass this column "
                            f"using parse_dates instead")
        else:
            raise TypeError(f"the dtype {dtype} is not supported for parsing")

    # -> tuple[ArrayLike, int]
    cdef _string_convert(self, Py_ssize_t i, int64_t start, int64_t end,
                         bint na_filter, kh_str_starts_t *na_hashset,
                         bint allow_pyarrow=False):

        cdef str target = ""
        cdef str resolved
        if allow_pyarrow:
            # The option lookups behind the target decision are not free and
            # run under the GIL, so resolve them once per reader rather than
            # once per column chunk.  This pins which path the parser takes at
            # the first string column converted, so changing the options
            # mid-read (possible only with chunksize / iterator=True) no longer
            # moves one read on or off the fast path partway through.  The
            # object path still picks its storage downstream, per chunk.
            if self._pa_target is None:
                # resolve into a local and publish once, so no observer can
                # see the "" placeholder while the lookups below are running
                resolved = ""
                if HAS_PYARROW and self.encoding_errors == b"strict":
                    if self.dtype_backend == "pyarrow":
                        resolved = "arrow"
                    elif (
                        self.dtype_backend == "numpy"
                        and using_string_dtype()
                        # an ArrowStringArray result would be inconsistent
                        # with mode.string_storage="python"
                        and StringDtype(na_value=np.nan).storage == "pyarrow"
                    ):
                        resolved = "str_nan"
                self._pa_target = resolved
            target = self._pa_target

        if target:
            try:
                return _string_pyarrow_utf8(self.parser, i, start, end,
                                            na_filter, na_hashset, target,
                                            self.defer_pa_wrap)
            except OverflowError:
                # >2GiB of string data does not fit the "arrow" target's
                # int32 offsets; the object path below chunks as needed.
                pass

        return _string_box_utf8(self.parser, i, start, end, na_filter,
                                na_hashset, self.encoding_errors)

    # -> ExtensionArray | None
    cdef _parse_numeric_natural(self, Py_ssize_t i, int64_t start,
                                int64_t end, bint na_filter,
                                kh_str_starts_t *na_hashset, set na_fset):
        # Parse a column with the same nogil converters the col_dtype=None
        # inference path uses (int64 -> uint64 -> float64) and build the natural
        # numpy-nullable array (IntegerArray / FloatingArray) -- i.e. what
        # ``read_csv(dtype_backend="numpy_nullable")`` produces.  Returns that
        # array, or None to signal "not confidently numeric" (non-numeric data,
        # or ints wider than uint64 which the string path renders as Python
        # ints), in which case the caller should fall back to the string path.
        cdef:
            object ivals = None
            # NA count from the int64 parse; -1 == unknown (uint64 path),
            # None if the int64 parse bailed (falls through to the float parse)
            object int_na_count = -1

        try:
            ivals, int_na_count = _try_int64(self.parser, i, start, end,
                                             na_filter, na_hashset, True)
        except OverflowError:
            try:
                ivals = _try_uint64(self.parser, i, start, end,
                                    na_filter, na_hashset, True)
            except (OverflowError, ValueError):
                return None
            if ivals is None:
                return None
        except ValueError as err:
            if str(err) != "Number is not int":
                return None
            # decimal / exponent form -> fall through to the float parse
            ivals = None

        if ivals is not None:
            # Build the NA mask from the actual NA positions rather than from
            # the integer sentinel value, so a legitimate int64-min / uint64-max
            # token is preserved instead of being mistaken for NA (which the
            # sentinel-based _maybe_upcast inference path gets wrong).  The
            # common no-NA case skips the extra scan.
            if not na_filter or int_na_count == 0:
                mask = np.zeros(len(ivals), dtype=bool)
            else:
                mask = self._na_bool_mask(i, start, end, na_filter, na_hashset)
            return IntegerArray(ivals, mask)

        fvals, _ = _try_double(self.parser, i, start, end,
                               na_filter, na_hashset, na_fset)
        if fvals is None:
            return None
        return _maybe_upcast(fvals, use_dtype_backend=True,
                             dtype_backend="numpy_nullable")

    # -> tuple[ExtensionArray, int] | None
    cdef _reconcile_numeric(self, natural, array_type, dtype):
        # Reconcile the natural nullable array to the requested nullable /
        # pyarrow dtype through _from_sequence -- exactly what
        #   _from_sequence_of_strings(to_numeric(strings, "numpy_nullable"))
        # does after parsing.  Returns (ExtensionArray, na_count), or None so
        # the caller falls back to the generic string path when the requested
        # dtype cannot hold the parsed values -- so the raised error matches
        # legacy behavior exactly.
        try:
            result = array_type._from_sequence(natural, dtype=dtype)
        except (TypeError, ValueError, OverflowError):
            return None
        return result, int(natural._mask.sum())

    # -> tuple[ExtensionArray, int] | None
    cdef _convert_masked_numeric(self, dtype, Py_ssize_t i, int64_t start,
                                 int64_t end, bint na_filter,
                                 kh_str_starts_t *na_hashset, set na_fset):
        # Fast path for numpy-nullable Integer/Floating dtypes, bypassing the
        # ndarray[object] + to_numeric round-trip in _from_sequence_of_strings.
        natural = self._parse_numeric_natural(
            i, start, end, na_filter, na_hashset, na_fset)
        if natural is None:
            return None
        return self._reconcile_numeric(natural, dtype.construct_array_type(),
                                       dtype)

    # -> tuple[BooleanArray, int] | None
    cdef _convert_boolean_masked(self, Py_ssize_t i, int64_t start,
                                 int64_t end, bint na_filter,
                                 kh_str_starts_t *na_hashset):
        # Fast path for the nullable "boolean" dtype, bypassing the
        # ndarray[object] + Python map() round-trip in _from_sequence_of_strings.
        cdef:
            Py_ssize_t lines = end - start
            ndarray[uint8_t] data = np.empty(lines, dtype=np.uint8)
            ndarray[uint8_t] mask = np.zeros(lines, dtype=np.uint8)
            int error

        with nogil:
            error = _try_boolean_masked_nogil(
                self.parser, i, start, end, na_filter, na_hashset,
                self.true_set, self.false_set,
                <uint8_t *>data.data, <uint8_t *>mask.data)
        if error != 0:
            # Unrecognized token spelling; defer to the generic string path so
            # the raised error (and any user none_values) matches legacy exactly.
            return None
        return (BooleanArray(data.view(np.bool_), mask.view(np.bool_)),
                int(mask.sum()))

    cdef _na_bool_mask(self, Py_ssize_t i, int64_t start, int64_t end,
                       bint na_filter, kh_str_starts_t *na_hashset):
        # Boolean mask of the NA rows in a column, derived from the NA hashset.
        cdef:
            Py_ssize_t j, lines = end - start
            coliter_t it
            const char *word = NULL
            c_int64_t token_idx = 0
            ndarray[uint8_t, cast=True] mask = np.zeros(lines, dtype=bool)
            uint8_t *mptr = <uint8_t *>mask.data

        if na_filter:
            coliter_setup(&it, self.parser, i, start)
            with nogil:
                for j in range(lines):
                    word = coliter_next_with_idx(&it, &token_idx)
                    if kh_get_str_starts_item(
                        na_hashset, word,
                        <size_t>_token_len(self.parser, token_idx)
                    ):
                        mptr[j] = 1
        return mask

    # -> tuple[ExtensionArray, int] | None
    cdef _convert_arrow(self, dtype, Py_ssize_t i, int64_t start,
                        int64_t end, bint na_filter,
                        kh_str_starts_t *na_hashset, set na_fset):
        # Fast path for pyarrow-backed (:class:`ArrowDtype`) columns.
        import pyarrow as pa

        pa_type = dtype.pyarrow_dtype
        if pa.types.is_integer(pa_type) or pa.types.is_floating(pa_type):
            # Parse with the same C converters as dtype_backend="pyarrow"
            # inference (and the nullable fast path above), then wrap as pyarrow.
            # This keeps explicit "int64[pyarrow]" parsing identical to
            # dtype_backend="pyarrow" rather than adopting pyarrow's more lenient
            # string casting (which would e.g. accept "0x1F").
            natural = self._parse_numeric_natural(
                i, start, end, na_filter, na_hashset, na_fset)
            if natural is None:
                return None
            return self._reconcile_numeric(
                natural, dtype.construct_array_type(), dtype)

        if not (pa.types.is_timestamp(pa_type)
                or pa.types.is_date(pa_type)
                or pa.types.is_duration(pa_type)
                or pa.types.is_time(pa_type)
                or pa.types.is_boolean(pa_type)
                or pa.types.is_string(pa_type)
                or pa.types.is_large_string(pa_type)
                or pa.types.is_binary(pa_type)):
            # decimal and any other type keep the generic path (unchanged).
            return None

        # Build a pyarrow large_string array straight from the C buffers (nogil)
        # and let _from_sequence_of_strings convert it with pyarrow compute
        # (to_datetime / cast, nogil C++).  These conversions use the same
        # engine as the generic object path, so results are unchanged.
        strings, na_count = _string_pyarrow_utf8(
            self.parser, i, start, end, na_filter, na_hashset, "str_nan")
        if isinstance(strings, np.ndarray):
            # _string_pyarrow_utf8 fell back to the object path (invalid UTF-8)
            return None

        array_type = dtype.construct_array_type()
        try:
            result = array_type._from_sequence_of_strings(
                strings._pa_array, dtype=dtype)
        except (ValueError, TypeError, NotImplementedError):
            # pyarrow raises ArrowInvalid (a ValueError) / ArrowNotImplemented
            # (a NotImplementedError) on values it cannot convert; defer to the
            # generic path so the error matches legacy behavior.
            return None
        return result, na_count

    cdef void _validate_usecols_and_names(self, int num_cols):
        usecols_not_callable_and_exists = not callable(self.usecols) and self.usecols
        names_larger_num_cols = (self.names and
                                 len(self.names) - self.leading_cols > num_cols)

        if self.table_width - self.leading_cols > num_cols:
            if (usecols_not_callable_and_exists
                    and self.table_width - self.leading_cols < len(self.usecols)
                    or names_larger_num_cols):
                raise ParserError(f"Too many columns specified: expected "
                                  f"{self.table_width - self.leading_cols} "
                                  f"and found {num_cols}")

        if (usecols_not_callable_and_exists and
                all(isinstance(u, int) for u in self.usecols)):
            missing_usecols = [col for col in self.usecols if col >= num_cols]
            if missing_usecols:
                raise ParserError(
                    "Defining usecols with out-of-bounds indices is not allowed. "
                    f"{missing_usecols} are out of bounds.",
                )

    # -> DtypeObj
    cdef object _get_col_dtype(self, int64_t i, bint is_default_dict_dtype, name):
        col_dtype = None
        if self.dtype is not None:
            if isinstance(self.dtype, dict):
                if name in self.dtype:
                    col_dtype = self.dtype[name]
                elif i in self.dtype:
                    col_dtype = self.dtype[i]
                elif is_default_dict_dtype:
                    col_dtype = self.dtype[name]
            else:
                if self.dtype.names:
                    # structured array
                    col_dtype = np.dtype(self.dtype.descr[i][1])
                else:
                    col_dtype = self.dtype
        return col_dtype

    def _get_converter(self, i: int, name):
        if self.converters is None:
            return None

        if name is not None and name in self.converters:
            return self.converters[name]

        # Converter for position, if any
        return self.converters.get(i)

    cdef _get_na_list(self, Py_ssize_t i, name):
        if isinstance(self.na_values, dict):
            key = None
            values = None

            if name is not None and name in self.na_values:
                key = name
            elif i in self.na_values:
                key = i
            else:  # No na_values provided for this column.
                if self.keep_default_na:
                    return _NA_VALUES, set()

                return list(), set()

            values = self.na_values[key]
            if values is not None and not isinstance(values, list):
                values = list(values)

            fvalues = self.na_fvalues[key]
            if fvalues is not None and not isinstance(fvalues, set):
                fvalues = set(fvalues)

            return _ensure_encoded(values), fvalues
        else:
            return _ensure_encoded(self.na_values), self.na_fvalues

    cdef _free_na_set(self, kh_str_starts_t *table):
        kh_destroy_str_starts(table)

    cdef _get_column_name(self, Py_ssize_t i, Py_ssize_t nused):
        cdef int64_t j
        if self.has_usecols and self.names is not None:
            if (not callable(self.usecols) and
                    len(self.names) == len(self.usecols)):
                return self.names[nused]
            else:
                return self.names[i - self.leading_cols]
        else:
            if self.header is not None:
                j = i - self.leading_cols
                # generate extra (bogus) headers if there are more columns than headers
                # These should be strings, not integers, because otherwise we might get
                # issues with callables as usecols GH#46997
                if j >= len(self.header[0]):
                    return str(j)
                elif self.has_mi_columns:
                    return tuple(header_row[j] for header_row in self.header)
                else:
                    return self.header[0][j]
            else:
                return None

# Factor out code common to TextReader.__dealloc__ and TextReader.close
# It cannot be a class method, since calling self.close() in __dealloc__
# which causes a class attribute lookup and violates best practices
# https://cython.readthedocs.io/en/latest/src/userguide/special_methods.html#finalization-method-dealloc
cdef _close(TextReader reader):
    reader.is_closed = True
    # Drop the pre-loaded buffer reference deterministically so the caller
    # can close the backing mmap (free-threaded builds may otherwise delay
    # the release past pool shutdown).
    reader._buffer_ref = None
    # Preemptively free all allocated memory, without the GIL: on macOS
    # freeing the (potentially large) data buffers gives pages back to the
    # OS via madvise, which would otherwise stall every other parser thread
    # in the parallel-read path. del_rd_source re-acquires the GIL for its
    # decrefs.
    with nogil:
        parser_free(reader.parser)
    if reader.true_set:
        kh_destroy_str_starts(reader.true_set)
        reader.true_set = NULL
    if reader.false_set:
        kh_destroy_str_starts(reader.false_set)
        reader.false_set = NULL


cdef:
    list _true_values = [b"True", b"TRUE", b"true"]
    list _false_values = [b"False", b"FALSE", b"false"]


def _ensure_encoded(list lst):
    cdef:
        list result = []
    for x in lst:
        if isinstance(x, str):
            x = PyUnicode_AsUTF8String(x)
        elif not isinstance(x, bytes):
            x = str(x).encode("utf-8")

        result.append(x)
    return result


# common NA values
# no longer excluding inf representations
# '1.#INF','-1.#INF', '1.#INF000000',
STR_NA_VALUES = {
    "-1.#IND",
    "1.#QNAN",
    "1.#IND",
    "-1.#QNAN",
    "#N/A N/A",
    "#N/A",
    "N/A",
    "n/a",
    "NA",
    "<NA>",
    "#NA",
    "NULL",
    "null",
    "NaN",
    "-NaN",
    "nan",
    "-nan",
    "",
    "None",
}
_NA_VALUES = _ensure_encoded(list(STR_NA_VALUES))


def _maybe_upcast(
    arr, use_dtype_backend: bool = False, dtype_backend: str = "numpy"
):
    """Sets nullable dtypes or upcasts if nans are present.

    Upcast, if use_dtype_backend is false and nans are present so that the
    current dtype can not hold the na value. We use nullable dtypes if the
    flag is true for every array.

    Parameters
    ----------
    arr: ndarray
        Numpy array that is potentially being upcast.

    use_dtype_backend: bool, default False
        If true, we cast to the associated nullable dtypes.

    Returns
    -------
    The casted array.
    """
    if isinstance(arr, _PendingStringColumn):
        # Deferred string column from the pyarrow fast path; the
        # c_parser_wrapper layer materializes it into an ExtensionArray.
        return arr

    if isinstance(arr.dtype, ExtensionDtype):
        # TODO: the docstring says arr is an ndarray, in which case this cannot
        #  be reached. Is that incorrect?
        return arr

    if arr.dtype.kind in "Mm":
        # datetime64/timedelta64 already carry NaT as the missing-value
        # sentinel; no upcast is required.
        return arr

    na_value = na_values[arr.dtype]

    if issubclass(arr.dtype.type, np.integer):
        mask = arr == na_value

        if use_dtype_backend:
            arr = IntegerArray(arr, mask)
        else:
            arr = arr.astype(float)
            np.putmask(arr, mask, np.nan)

    elif arr.dtype == np.bool_:
        mask = arr.view(np.uint8) == na_value

        if use_dtype_backend:
            arr = BooleanArray(arr, mask)
        else:
            arr = arr.astype(object)
            np.putmask(arr, mask, np.nan)

    elif issubclass(arr.dtype.type, float) or arr.dtype.type == np.float32:
        if use_dtype_backend:
            mask = np.isnan(arr)
            arr = FloatingArray(arr, mask)

    elif arr.dtype == np.object_:
        if use_dtype_backend:
            if dtype_backend == "pyarrow":
                # using the StringDtype below would use large_string by default
                # keep here to pyarrow's default of string
                import pyarrow as pa
                dtype = ArrowDtype(pa.string())
            else:
                dtype = StringDtype()
            cls = dtype.construct_array_type()
            arr = cls._from_sequence(arr, dtype=dtype)

    if use_dtype_backend and dtype_backend == "pyarrow":
        import pyarrow as pa
        if isinstance(arr, IntegerArray) and arr.isna().all():
            # use null instead of int64 in pyarrow
            arr = arr.to_numpy(na_value=None)
        arr = ArrowExtensionArray(pa.array(arr, from_pandas=is_nan_na()))

    return arr


# ----------------------------------------------------------------------
# Type conversions / inference support code


# -> tuple[ndarray[object], int]
@cython.wraparound(False)
@cython.boundscheck(False)
cdef _string_box_utf8(parser_t *parser, int64_t col,
                      int64_t line_start, int64_t line_end,
                      bint na_filter, kh_str_starts_t *na_hashset,
                      const char *encoding_errors):
    cdef:
        int na_count = 0
        Py_ssize_t i, lines
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        int64_t word_len
        ndarray[object] result

        int ret = 0
        kh_strbox_t *table

        object pyval

        object NA = na_values[np.object_]
        khiter_t k

    table = kh_init_strbox()
    lines = line_end - line_start
    result = np.empty(lines, dtype=np.object_)
    coliter_setup(&it, parser, col, line_start)

    for i in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        word_len = _token_len(parser, token_idx)

        if na_filter:
            if kh_get_str_starts_item(na_hashset, word, <size_t>word_len):
                # in the hash table
                na_count += 1
                result[i] = NA
                continue

        # no deletions from this table, so ret == 0 means already present.
        # The key carries its length, so two fields that differ only past an
        # embedded NUL no longer intern to the same object.
        k = kh_put_strbox(table, kh_strview(word, <size_t>word_len), &ret)

        # in the hash table
        if ret == 0:
            # this increments the refcount, but need to test
            pyval = <object>table.vals[k]
        else:
            pyval = PyUnicode_DecodeUTF8(word, word_len, encoding_errors)

            table.vals[k] = <PyObject *>pyval

        result[i] = pyval

    kh_destroy_strbox(table)

    return result, na_count


# Prebuilt at import time so that `_string_pyarrow_utf8`, which runs once per
# (column, chunk), does no import machinery or dtype construction while holding
# the GIL.  Populating these lazily instead would race between the threads of a
# parallel read.  Nothing is imported here that pandas has not already imported:
# HAS_PYARROW is only true once ``pyarrow`` is in sys.modules, and
# ``pandas.core.arrays`` exports ArrowStringArray.
cdef object _pa_large_string_type = None
cdef object _pa_string_type = None
cdef object _pa_str_nan_dtype = None
cdef object _pa_arrow_str_dtype = None
cdef object _pa_py_buffer = None
cdef object _pa_foreign_buffer = None
cdef object _pa_from_buffers = None
cdef object _pa_chunked_array = None
cdef object _pa_ArrowInvalid = None

if HAS_PYARROW:
    import pyarrow as pa

    _pa_large_string_type = pa.large_string()
    _pa_string_type = pa.string()
    # storage is passed explicitly rather than left to mode.string_storage:
    # this outlives the option, and the "str_nan" target is only ever chosen
    # when the option resolves to "pyarrow" anyway.
    _pa_str_nan_dtype = StringDtype(storage="pyarrow", na_value=np.nan)
    _pa_arrow_str_dtype = ArrowDtype(_pa_string_type)
    # bound here too, so `_string_pyarrow_utf8` does no pyarrow attribute
    # lookups of its own
    _pa_py_buffer = pa.py_buffer
    _pa_foreign_buffer = pa.foreign_buffer
    _pa_from_buffers = pa.Array.from_buffers
    _pa_chunked_array = pa.chunked_array
    _pa_ArrowInvalid = pa.lib.ArrowInvalid


cdef void _free_malloc_capsule(object capsule) noexcept:
    free(PyCapsule_GetPointer(capsule, NULL))


cdef class _PendingStringColumn:
    """
    Raw malloc'd buffers for one parsed string column chunk, produced
    without numpy/pyarrow object creation so parallel-read workers touch
    the GIL as little as possible; `materialize()` wraps them into a
    pyarrow Array.
    """
    cdef:
        int64_t *offsets64_ptr
        int32_t *offsets32_ptr
        uint8_t *validity_ptr
        char *data_ptr
        Py_ssize_t lines
        Py_ssize_t total_bytes
        int na_count
        bint large

    def __dealloc__(self):
        # Only owns whatever materialize() has not yet transferred.
        free(self.offsets64_ptr)
        free(self.offsets32_ptr)
        free(self.validity_ptr)
        free(self.data_ptr)

    def __len__(self) -> int:
        return self.lines

    @property
    def dtype(self):
        """
        The dtype `materialize()` will produce.  Lets a caller reconcile
        dtypes across chunks (see the parallel-read gather) while the
        columns are still unmaterialized.
        """
        return _pa_str_nan_dtype if self.large else _pa_arrow_str_dtype

    def materialize(self):
        """
        Build a pyarrow Array from the buffers; ownership moves to pyarrow
        via capsule-based foreign buffers, so this can be called only once.
        """
        cdef uintptr_t addr
        if self.data_ptr == NULL:
            # A fresh instance always has a non-NULL data_ptr (malloc'd at
            # least 1 byte); NULL means the buffers were already transferred.
            raise RuntimeError("materialize() may only be called once")

        if self.large:
            addr = <uintptr_t>self.offsets64_ptr
            capsule = PyCapsule_New(<void *>self.offsets64_ptr, NULL,
                                    _free_malloc_capsule)
            self.offsets64_ptr = NULL
            offsets_buf = _pa_foreign_buffer(
                addr, (self.lines + 1) * sizeof(int64_t), capsule
            )
            pa_type = _pa_large_string_type
        else:
            addr = <uintptr_t>self.offsets32_ptr
            capsule = PyCapsule_New(<void *>self.offsets32_ptr, NULL,
                                    _free_malloc_capsule)
            self.offsets32_ptr = NULL
            offsets_buf = _pa_foreign_buffer(
                addr, (self.lines + 1) * sizeof(int32_t), capsule
            )
            pa_type = _pa_string_type

        if self.na_count > 0:
            addr = <uintptr_t>self.validity_ptr
            capsule = PyCapsule_New(<void *>self.validity_ptr, NULL,
                                    _free_malloc_capsule)
            self.validity_ptr = NULL
            validity_buf = _pa_foreign_buffer(
                addr, (self.lines + 7) // 8, capsule
            )
        else:
            validity_buf = None
            free(self.validity_ptr)
            self.validity_ptr = NULL

        addr = <uintptr_t>self.data_ptr
        capsule = PyCapsule_New(<void *>self.data_ptr, NULL,
                                _free_malloc_capsule)
        self.data_ptr = NULL
        data_buf = _pa_foreign_buffer(addr, self.total_bytes, capsule)

        return _pa_from_buffers(
            pa_type, self.lines, [validity_buf, offsets_buf, data_buf],
            null_count=self.na_count,
        )


cdef int _days_per_month_array[12]
_days_per_month_array[:] = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]


cdef inline bint _all_digits(const char *chars, int start,
                             int stop) noexcept nogil:
    cdef int idx
    for idx in range(start, stop):
        if chars[idx] < b"0" or chars[idx] > b"9":
            return False
    return True


cdef inline int _two_digits(const char *chars, int pos) noexcept nogil:
    return (chars[pos] - ord("0")) * 10 + (chars[pos + 1] - ord("0"))


cdef inline int _parse_iso_fixed(const char *word, Py_ssize_t word_len,
                                 npy_datetimestruct *dts,
                                 NPY_DATETIMEUNIT *out_bestunit) noexcept nogil:
    """
    Faster equivalent to `parse_iso_8601_datetime` for the two dominant
    fixed-width layouts: `YYYY-MM-DD` and `YYYY-MM-DD[ T]HH:MM:SS` (always
    timezone-naive). Returns 0 on success, -1 to defer to the general
    parser, applying the same calendar/range validation it would.

    This arguably belongs in tslibs alongside `string_to_dts`, but is kept
    here so it stays inlined into the loop below; reached as a cross-module
    cdef it measured ~5% slower on this fastpath.
    """
    cdef:
        int year, month, day, days_in_month
        char sep

    if word_len != 19 and word_len != 10:
        return -1
    if word[4] != b"-" or word[7] != b"-":
        return -1
    if not _all_digits(word, 0, 4):
        return -1
    if not _all_digits(word, 5, 7) or not _all_digits(word, 8, 10):
        return -1

    year = (
        (word[0] - ord("0")) * 1000 + (word[1] - ord("0")) * 100
        + (word[2] - ord("0")) * 10 + (word[3] - ord("0"))
    )
    month = _two_digits(word, 5)
    day = _two_digits(word, 8)
    if month < 1 or month > 12:
        return -1
    days_in_month = _days_per_month_array[month - 1]
    if month == 2 and year % 4 == 0 and (year % 100 != 0 or year % 400 == 0):
        days_in_month = 29
    if day < 1 or day > days_in_month:
        return -1

    memset(dts, 0, sizeof(npy_datetimestruct))
    dts.year = year
    dts.month = month
    dts.day = day

    if word_len == 10:
        out_bestunit[0] = NPY_DATETIMEUNIT.NPY_FR_D
        return 0

    sep = word[10]
    if sep != b" " and sep != b"T":
        return -1
    if word[13] != b":" or word[16] != b":":
        return -1
    if not _all_digits(word, 11, 13):
        return -1
    if not _all_digits(word, 14, 16) or not _all_digits(word, 17, 19):
        return -1
    dts.hour = _two_digits(word, 11)
    dts.min = _two_digits(word, 14)
    dts.sec = _two_digits(word, 17)
    if dts.hour > 23 or dts.min > 59 or dts.sec > 59:
        return -1
    out_bestunit[0] = NPY_DATETIMEUNIT.NPY_FR_s
    return 0


cdef inline int _layout_code(const char *word,
                             Py_ssize_t word_len) noexcept nogil:
    """
    Layout of a string already known to parse via `_parse_iso_fixed`:
    1 (YYYY-MM-DD), 2 (space-separated) or 3 (T-separated). Two such strings
    share a format shape exactly when their codes match, giving an O(1)
    equivalent of `_same_format_shape` on the fastpath.
    """
    if word_len == 10:
        return 1
    return 2 if word[10] == b" " else 3


cdef inline int _fixed_shape_code(const char *word,
                                  Py_ssize_t word_len) noexcept nogil:
    """
    `_layout_code` for an unvalidated string, or 0 if it is not fixed-layout.
    """
    cdef:
        npy_datetimestruct dts
        NPY_DATETIMEUNIT unit

    if _parse_iso_fixed(word, word_len, &dts, &unit) != 0:
        return 0
    return _layout_code(word, word_len)


cdef inline bint _same_format_shape(const char *left, Py_ssize_t left_len,
                                    const char *right,
                                    Py_ssize_t right_len) noexcept nogil:
    """
    Check whether two datetime strings share a layout: same length, digits and
    non-digits in the same positions, and identical non-digit characters.
    This conservatively approximates "both match the strptime format inferred
    from the first" — false negatives only cost the fastpath.
    """
    cdef:
        Py_ssize_t j
        bint left_digit, right_digit

    if left_len != right_len:
        return False
    for j in range(left_len):
        left_digit = 48 <= <unsigned char>left[j] <= 57  # "0"-"9"
        right_digit = 48 <= <unsigned char>right[j] <= 57
        if left_digit != right_digit:
            return False
        if not left_digit and left[j] != right[j]:
            return False
    return True


cdef class _DatetimeChunkState:
    """
    Per-read state for the parse_dates fastpath in low_memory mode: keeps the
    format template and tz-awareness consistent across chunks, and holds
    raw-byte receipts so a later chunk's fallback can rebuild earlier chunks'
    object-string arrays exactly.
    """
    cdef public:
        bint failed
        bint saw_tz, saw_naive
        int first_tzoffset
        int creso_seen  # NPY_DATETIMEUNIT of the last parsed chunk, -1 unset
        bytes template
        list receipts  # list[tuple[chunk_idx, arena, offsets, use_be]]

    def __cinit__(self):
        self.failed = False
        self.saw_tz = False
        self.saw_naive = False
        self.first_tzoffset = 0
        self.creso_seen = -1
        self.template = None
        self.receipts = []


@cython.wraparound(False)
@cython.boundscheck(False)
cdef _collect_arena(parser_t *parser, int64_t col,
                    int64_t line_start, int64_t line_end,
                    bint na_filter, kh_str_starts_t *na_hashset,
                    Py_ssize_t arena_size):
    """
    Copy a column's raw NUL-terminated words into one bytes arena, with
    per-row offsets (-1 for na_values hits). Together with `_box_arena_utf8`
    this lets the fastpath reconstruct exactly what `_string_box_utf8` would
    have produced.

    Only reached for chunks whose every non-NA word ISO-parsed at its full
    `_token_len`, so words contain no embedded NULs and NUL-terminated storage
    round-trips exactly here and in `_box_arena_utf8`.
    """
    cdef:
        Py_ssize_t i, lines, word_len, pos = 0
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        bytes arena = PyBytes_FromStringAndSize(NULL, arena_size)
        char *buf = PyBytes_AsString(arena)
        ndarray[int64_t] offsets

    lines = line_end - line_start
    offsets = np.empty(lines, dtype=np.int64)
    coliter_setup(&it, parser, col, line_start)

    for i in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        word_len = _token_len(parser, token_idx)
        if na_filter and kh_get_str_starts_item(na_hashset, word,
                                                <size_t>word_len):
            offsets[i] = -1
            continue
        word_len += 1  # include the NUL
        memcpy(buf + pos, word, word_len)
        offsets[i] = pos
        pos += word_len

    return arena, offsets


@cython.wraparound(False)
@cython.boundscheck(False)
cdef _box_arena_utf8(bytes arena, const int64_t[::1] offsets,
                     const char *encoding_errors):
    """
    Rebuild the object-string array `_string_box_utf8` would have produced,
    from an arena captured by `_collect_arena`.
    """
    cdef:
        Py_ssize_t i, lines = offsets.shape[0], word_len
        const char *buf = PyBytes_AsString(arena)
        const char *word
        ndarray[object] result = np.empty(lines, dtype=np.object_)
        int ret = 0
        kh_strbox_t *table
        object pyval
        object NA = na_values[np.object_]
        khiter_t k

    table = kh_init_strbox()
    for i in range(lines):
        if offsets[i] == -1:
            result[i] = NA
            continue
        word = buf + offsets[i]
        word_len = strlen(word)

        k = kh_get_strbox(table, kh_strview(word, <size_t>word_len))
        if k != table.n_buckets:
            pyval = <object>table.vals[k]
        else:
            pyval = PyUnicode_DecodeUTF8(word, word_len, encoding_errors)
            k = kh_put_strbox(table, kh_strview(word, <size_t>word_len), &ret)
            table.vals[k] = <PyObject *>pyval

        result[i] = pyval

    kh_destroy_strbox(table)
    return result


# -> tuple[ArrayLike, int] | tuple[None, 0]
@cython.wraparound(False)
@cython.boundscheck(False)
cdef _datetime_box_utf8(parser_t *parser, int64_t col,
                        int64_t line_start, int64_t line_end,
                        bint na_filter, kh_str_starts_t *na_hashset,
                        bint require_consistent_format,
                        _DatetimeChunkState state=None,
                        int64_t chunk_idx=0,
                        bint use_dtype_backend=False,
                        NPY_DATETIMEUNIT force_creso=NPY_DATETIMEUNIT.NPY_FR_GENERIC):
    """
    Faster equivalent to `_string_box_utf8` + `to_datetime(...)` for
    ISO8601-formatted datetime columns: parse each tokenized field directly
    from the tokenizer's `const char *` buffer into a datetime64 output array,
    skipping the intermediate object ndarray of Python strings.

    With `require_consistent_format=True` (the `date_format=None` case), every
    value must share the layout of the first parsed value, mirroring
    `to_datetime`'s infer-format-from-first-element behavior. With False (the
    `date_format="ISO8601"` case), any mix of ISO8601 layouts is accepted.

    `state` is the cross-chunk state in low_memory mode (None otherwise); on
    success it is updated and a raw-byte receipt of this chunk is recorded,
    with `use_dtype_backend` stored for fallback reconstruction.

    `force_creso` is used during a recursive reparse triggered by mid-column
    resolution bumps. When it is the sentinel `NPY_FR_GENERIC`, resolution is
    inferred per-row.

    Returns (result, na_count) on success, or (None, 0) to signal that the
    caller should fall back to the object-string path.
    """
    cdef:
        int na_count = 0
        Py_ssize_t i, lines, word_len
        Py_ssize_t arena_size = 0
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        ndarray result
        int64_t[::1] iresult
        npy_datetimestruct dts
        NPY_DATETIMEUNIT out_bestunit, item_reso
        NPY_DATETIMEUNIT creso = NPY_DATETIMEUNIT.NPY_FR_us
        NPY_DATETIMEUNIT bump_reso = NPY_DATETIMEUNIT.NPY_FR_GENERIC
        int out_local = 0, out_tzoffset = 0
        int ret
        bint creso_set = False
        bint tz_set = False
        bint saw_tz = False, saw_naive = False
        bint fallback = False
        bint fixed_ok = False
        int template_fixed = -1
        int first_tzoffset = 0
        int64_t offset_in_unit, tz_offset_mult
        const char *template_word = NULL
        Py_ssize_t template_len = 0
        bytes state_template = None

    if force_creso != NPY_DATETIMEUNIT.NPY_FR_GENERIC:
        creso = force_creso
        creso_set = True

    if state is not None:
        saw_tz = state.saw_tz
        saw_naive = state.saw_naive
        tz_set = state.saw_tz
        first_tzoffset = state.first_tzoffset
        # Keep a reference so the char buffer stays valid for the loop.
        state_template = state.template
        if state_template is not None:
            template_word = state_template
            template_len = len(state_template)
            template_fixed = _fixed_shape_code(template_word, template_len)

    lines = line_end - line_start
    # Output buffer holds int64s at `creso` resolution; the final dtype is
    # assigned via a view once the final creso is known (matching
    # array_strptime's behavior of flooring at us for ISO8601 inputs).
    result = np.empty(lines, dtype="M8[us]")
    iresult = result.view("i8")
    coliter_setup(&it, parser, col, line_start)

    # nogil here helps only caller-managed threads; read_csv's own parallel
    # path is disabled when parse_dates is set.  Bail-outs must set `fallback`
    # (or `bump_reso`) and break rather than return from inside the block.
    try:
        with nogil:
            for i in range(lines):
                word = coliter_next_with_idx(&it, &token_idx)

                # _token_len, not strlen: an embedded NUL must reach the ISO
                # parser and fail, so the column falls back like the object path.
                word_len = _token_len(parser, token_idx)

                if na_filter and kh_get_str_starts_item(na_hashset, word,
                                                        <size_t>word_len):
                    na_count += 1
                    iresult[i] = NPY_NAT
                    continue

                arena_size += word_len + 1
                if word_len == 0:
                    na_count += 1
                    iresult[i] = NPY_NAT
                    continue

                fixed_ok = _parse_iso_fixed(word, word_len,
                                            &dts, &out_bestunit) == 0

                if require_consistent_format:
                    if template_word == NULL:
                        # Word pointers stay valid for this chunk's conversion.
                        template_word = word
                        template_len = word_len
                        template_fixed = (
                            _layout_code(word, word_len) if fixed_ok else 0
                        )
                    elif fixed_ok:
                        if template_fixed != _layout_code(word, word_len):
                            fallback = True
                            break
                    elif not _same_format_shape(template_word, template_len,
                                                word, word_len):
                        fallback = True
                        break

                if fixed_ok:
                    out_local = 0
                else:
                    ret = parse_iso_8601_datetime(
                        word, <int>word_len, 0,
                        &dts, &out_bestunit, &out_local, &out_tzoffset,
                        NULL, 0, INFER_FORMAT,
                    )
                    if ret:
                        fallback = True
                        break

                if out_local:
                    # Offsets are collected here and applied after the loop.
                    # Mixed naive+aware or differing offsets defer to the slow
                    # path, matching the existing error behavior.
                    if saw_naive:
                        fallback = True
                        break
                    if not tz_set:
                        first_tzoffset = out_tzoffset
                        tz_set = True
                    elif out_tzoffset != first_tzoffset:
                        fallback = True
                        break
                    saw_tz = True
                else:
                    if saw_tz:
                        fallback = True
                        break
                    saw_naive = True

                item_reso = get_supported_reso(out_bestunit)
                if item_reso < NPY_DATETIMEUNIT.NPY_FR_us:
                    item_reso = NPY_DATETIMEUNIT.NPY_FR_us

                if not creso_set:
                    creso = item_reso
                    creso_set = True
                elif item_reso > creso:
                    # Higher-resolution row: reparse the column below.
                    bump_reso = item_reso
                    break

                iresult[i] = npy_datetimestruct_to_datetime(creso, &dts)
                if iresult[i] == NPY_NAT:
                    # GH#66510 NA rows already `continue`d above, so this is a
                    # real value that rendered onto the NaT sentinel and would be
                    # indistinguishable from NA. Defer to the object path like
                    # any other date this fastpath cannot represent.
                    fallback = True
                    break
    except OverflowError:
        return None, 0

    if bump_reso != NPY_DATETIMEUNIT.NPY_FR_GENERIC:
        # Mirrors array_strptime's recursive reparse on `creso_ever_changed`
        # and keeps output values consistent with one another.
        return _datetime_box_utf8(
            parser, col, line_start, line_end,
            na_filter, na_hashset, require_consistent_format,
            state, chunk_idx, use_dtype_backend,
            force_creso=bump_reso,
        )

    if fallback:
        return None, 0

    if not creso_set:
        if state is not None and state.creso_seen != -1:
            # All-NA chunk after a parsed chunk: emit all-NaT at the prior
            # chunk's resolution (NA rows never affect resolution inference,
            # and EA concat upcasts mixed units losslessly anyway).
            creso = <NPY_DATETIMEUNIT>state.creso_seen
        else:
            # No values parsed in the whole read (all-NA or empty); defer to
            # the slow path so the dtype matches it (datetime64[s]).
            return None, 0

    if creso != NPY_DATETIMEUNIT.NPY_FR_us:
        result = iresult.base.view(f"M8[{npy_unit_to_abbrev(creso)}]")

    if saw_tz:
        # Normalize each non-NaT entry to UTC by subtracting the fixed offset.
        if creso == NPY_DATETIMEUNIT.NPY_FR_s:
            tz_offset_mult = 60
        elif creso == NPY_DATETIMEUNIT.NPY_FR_ms:
            tz_offset_mult = 60_000
        elif creso == NPY_DATETIMEUNIT.NPY_FR_us:
            tz_offset_mult = 60_000_000
        else:  # ns
            tz_offset_mult = 60_000_000_000
        offset_in_unit = first_tzoffset * tz_offset_mult
        for i in range(lines):
            if iresult[i] != NPY_NAT:
                # GH#65353 guard against int64 wraparound (or landing on NaT)
                # near the datetime64 bounds; bail so the value falls back to
                # the object path like any other unparsable date.
                if offset_in_unit > 0:
                    if iresult[i] <= INT64_MIN + offset_in_unit:
                        return None, 0
                elif iresult[i] > INT64_MAX + offset_in_unit:
                    return None, 0
                iresult[i] -= offset_in_unit

        if first_tzoffset == 0:
            tz = timezone.utc
        else:
            tz = timezone(timedelta(minutes=first_tzoffset))
        dtype = DatetimeTZDtype(tz=tz, unit=npy_unit_to_abbrev(creso))
        out = DatetimeArray._simple_new(result, dtype=dtype)
    else:
        # Wrap naive output in a DatetimeArray for consistency with the
        # tz-aware case; the ExtensionArray concat path then upcasts
        # mixed-unit datetime64 across chunks correctly where raw mixed-unit
        # M8 ndarrays would silently demote to object.
        out = DatetimeArray._simple_new(result, dtype=result.dtype)

    if state is not None:
        state.saw_tz = saw_tz
        state.saw_naive = saw_naive
        state.first_tzoffset = first_tzoffset
        state.creso_seen = <int>creso
        if (require_consistent_format and state.template is None
                and template_word != NULL):
            state.template = template_word[:template_len]
        arena, offsets = _collect_arena(
            parser, col, line_start, line_end, na_filter, na_hashset,
            arena_size)
        state.receipts.append((chunk_idx, arena, offsets, use_dtype_backend))

    return out, na_count


# -> tuple[ExtensionArray | _PendingStringColumn, int]
@cython.wraparound(False)
@cython.boundscheck(False)
cdef _string_pyarrow_utf8(parser_t *parser, int64_t col,
                          int64_t line_start, int64_t line_end,
                          bint na_filter, kh_str_starts_t *na_hashset,
                          str target, bint defer=False):
    """
    Build a pyarrow-backed string ExtensionArray directly from the C parser
    buffers, bypassing the intermediate ``ndarray[object]`` and its associated
    ``PyUnicode`` allocations plus the downstream ``_from_sequence`` walk.

    target = "str_nan"    -> ArrowStringArray with StringDtype(na_value=np.nan)
                             (default when ``using_string_dtype()`` is on)
    target = "arrow"      -> ArrowExtensionArray(pa.string())
                             (dtype_backend="pyarrow")

    For "str_nan" we use ``pa.large_string()`` (int64 offsets) to match
    StringDtype's pyarrow storage. For "arrow" we keep ``pa.string()`` (int32
    offsets) to match the dtype_backend="pyarrow" convention; raises
    OverflowError if the column exceeds 2GiB.

    With ``defer=True``, pure-ASCII columns are returned as a raw
    `_PendingStringColumn` (no numpy/pyarrow objects created); the
    c_parser_wrapper layer materializes them into one ExtensionArray per
    column at the end of the read.
    """
    cdef:
        int na_count = 0
        Py_ssize_t i, lines
        Py_ssize_t total_bytes = 0
        int64_t wlen, seg
        c_int64_t token_idx = 0
        coliter_t it
        const char *word = NULL
        int32_t *offsets32_ptr = NULL
        int64_t *offsets64_ptr = NULL
        uint8_t *validity_ptr = NULL
        char *data_ptr = NULL
        bint large = target == "str_nan"
        bint track_validity = na_filter
        bint overflow = False
        bint malloc_failed = False
        bint saw_non_ascii = False
        uint64_t ascii_acc = 0
        uint64_t HIGH_BITS = 0x8080808080808080
        const uint64_t *data_words = NULL
        Py_ssize_t nwords, block_start, block_end, jw
        _PendingStringColumn pending

    lines = line_end - line_start

    # Single GIL-free region covering every allocation and both passes:
    # pass 1 computes offsets / validity / na_count / total_bytes, the data
    # buffer is malloc'd once the size is known, and pass 2 copies each
    # token's bytes into its slot (segment lengths come from the pass-1
    # offsets, so na / empty rows are skipped without re-checking the na
    # hashset).  No numpy or pyarrow objects are created here, so parallel
    # workers spend almost no time holding the GIL.
    coliter_setup(&it, parser, col, line_start)
    with nogil:
        if large:
            offsets64_ptr = <int64_t *>malloc(
                (lines + 1) * sizeof(int64_t)
            )
            malloc_failed = offsets64_ptr == NULL
            if not malloc_failed:
                offsets64_ptr[0] = 0
        else:
            offsets32_ptr = <int32_t *>malloc(
                (lines + 1) * sizeof(int32_t)
            )
            malloc_failed = offsets32_ptr == NULL
            if not malloc_failed:
                offsets32_ptr[0] = 0

        if track_validity and not malloc_failed:
            # Start all-valid and clear bits on NA rows, so the common
            # no-NA case does no per-token bitmap work.  Padding bits in
            # the last byte stay set, which Arrow permits (their value is
            # unspecified).
            validity_ptr = <uint8_t *>malloc(
                (lines + 7) // 8 if lines else 1
            )
            malloc_failed = validity_ptr == NULL
            if not malloc_failed:
                memset(validity_ptr, 0xFF, (lines + 7) // 8)

        for i in range(lines if not malloc_failed else 0):
            word = coliter_next_with_idx(&it, &token_idx)

            # Not strlen: an embedded NUL is a data byte here, so strlen would
            # truncate the field at it (GH#66415).
            wlen = _token_len(parser, token_idx)

            if na_filter and kh_get_str_starts_item(na_hashset, word,
                                                    <size_t>wlen):
                na_count += 1
                validity_ptr[i >> 3] &= <uint8_t>(~(1 << (i & 7)))
                if large:
                    offsets64_ptr[i + 1] = <int64_t>total_bytes
                else:
                    offsets32_ptr[i + 1] = <int32_t>total_bytes
                continue

            if not large and total_bytes + wlen > <Py_ssize_t>INT32_MAX:
                overflow = True
                break

            total_bytes += wlen
            if large:
                offsets64_ptr[i + 1] = <int64_t>total_bytes
            else:
                offsets32_ptr[i + 1] = <int32_t>total_bytes

        if not overflow and not malloc_failed:
            # Allocate the data buffer exactly once, now the size is known.
            data_ptr = <char *>malloc(total_bytes if total_bytes else 1)
            if data_ptr == NULL:
                malloc_failed = True
            else:
                coliter_setup(&it, parser, col, line_start)
                for i in range(lines):
                    word = coliter_next(&it)
                    if large:
                        seg = offsets64_ptr[i + 1] - offsets64_ptr[i]
                        if seg:
                            memcpy(data_ptr + offsets64_ptr[i], word,
                                   <size_t>seg)
                    else:
                        seg = offsets32_ptr[i + 1] - offsets32_ptr[i]
                        if seg:
                            memcpy(data_ptr + offsets32_ptr[i], word,
                                   <size_t>seg)

                # ASCII probe: a clear high bit across the data buffer means
                # the column is pure ASCII, which is valid UTF-8 by
                # construction, so the validate(full=True) below can be
                # skipped.  Scan in 32KiB blocks so multibyte data bails out
                # after the first block.
                nwords = total_bytes >> 3
                data_words = <const uint64_t *>data_ptr
                block_start = 0
                while block_start < nwords and not saw_non_ascii:
                    block_end = block_start + 4096
                    if block_end > nwords:
                        block_end = nwords
                    for jw in range(block_start, block_end):
                        ascii_acc |= data_words[jw]
                    if ascii_acc & HIGH_BITS:
                        saw_non_ascii = True
                    block_start = block_end
                if not saw_non_ascii:
                    for jw in range(nwords << 3, total_bytes):
                        ascii_acc |= <uint8_t>data_ptr[jw]
                    saw_non_ascii = (ascii_acc & HIGH_BITS) != 0

    if overflow or malloc_failed:
        free(offsets64_ptr)
        free(offsets32_ptr)
        free(validity_ptr)
        free(data_ptr)
        if malloc_failed:
            raise MemoryError()
        raise OverflowError(
            "String column exceeds 2GiB, which is the maximum supported "
            "by pyarrow's 'string' type."
        )

    pending = _PendingStringColumn.__new__(_PendingStringColumn)
    pending.offsets64_ptr = offsets64_ptr
    pending.offsets32_ptr = offsets32_ptr
    pending.validity_ptr = validity_ptr
    pending.data_ptr = data_ptr
    pending.lines = lines
    pending.total_bytes = total_bytes
    pending.na_count = na_count
    pending.large = large

    if defer and not saw_non_ascii:
        # Caller materializes and wraps into one ExtensionArray per column
        # at the end of the read (see c_parser_wrapper), so worker threads
        # skip all pyarrow object construction while holding the GIL.
        # Non-ASCII chunks fall through to an eager materialize instead:
        # they need the UTF-8 validation below while the object-path
        # fallback is still possible (the parser rows are consumed once
        # this returns).
        return pending, na_count

    pa_arr = pending.materialize()

    # from_buffers does not validate UTF-8; fall back to the object path so
    # malformed bytes raise UnicodeDecodeError as before.  Pure-ASCII columns
    # (the common case) are valid UTF-8 by construction and skip this.
    if saw_non_ascii:
        try:
            pa_arr.validate(full=True)
        except _pa_ArrowInvalid:
            return _string_box_utf8(parser, col, line_start, line_end,
                                    na_filter, na_hashset, b"strict")

    # Bypass ArrowStringArray/ArrowExtensionArray.__init__ (type checks, dtype
    # construction) -- the exact type and dtype are known by construction.
    # This is `_from_pyarrow_array` inlined; that helper re-checks the pyarrow
    # type on every call, which we already know here.  The attribute set is
    # pinned by test_pyarrow_string_fast_path_attrs_match_constructor.
    if target == "str_nan":
        arr = ArrowStringArray.__new__(ArrowStringArray)
        arr._dtype = _pa_str_nan_dtype
    else:
        arr = ArrowExtensionArray.__new__(ArrowExtensionArray)
        arr._dtype = _pa_arrow_str_dtype
    arr._pa_array = _pa_chunked_array([pa_arr])
    arr._cache = {}
    return arr, na_count


@cython.wraparound(False)
@cython.boundscheck(False)
cdef _categorical_convert(parser_t *parser, int64_t col,
                          int64_t line_start, int64_t line_end,
                          bint na_filter, kh_str_starts_t *na_hashset,
                          const char *encoding_errors):
    "Convert column data into codes, categories"
    cdef:
        int na_count = 0
        Py_ssize_t i, lines
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        int64_t word_len

        int64_t NA = -1
        int64_t[::1] codes
        int64_t current_category = 0

        int ret = 0
        kh_str_t *table
        kh_strview_t key
        khiter_t k

        dict seen
        int64_t[::1] remap_view
        ndarray[object] result
        Py_ssize_t n_cats

    lines = line_end - line_start
    codes = np.empty(lines, dtype=np.int64)

    # factorize parsed values, creating a hash table
    # bytes -> category code
    with nogil:
        table = kh_init_str()
        coliter_setup(&it, parser, col, line_start)

        for i in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            word_len = _token_len(parser, token_idx)

            if na_filter:
                if kh_get_str_starts_item(na_hashset, word,
                                          <size_t>word_len):
                    # is in NA values
                    na_count += 1
                    codes[i] = NA
                    continue

            key = kh_strview(word, <size_t>word_len)
            k = kh_get_str(table, key)
            # not in the hash table
            if k == table.n_buckets:
                k = kh_put_str(table, key, &ret)
                table.vals[k] = current_category
                current_category += 1

            codes[i] = table.vals[k]

    # parse and box categories to python strings
    n_cats = table.n_occupied
    result = np.empty(n_cats, dtype=np.object_)
    for k in range(table.n_buckets):
        if kh_exist_str(table, k):
            result[table.vals[k]] = PyUnicode_DecodeUTF8(
                table.keys[k].ptr, table.keys[k].len, encoding_errors)

    kh_destroy_str(table)

    # The table dedupes on raw bytes, but a lossy encoding_errors can decode two
    # distinct keys to the same label (b"q\xff" and b"q\xfe" both -> "q�").
    # Merge those codes; leaving them split would build a Categorical with
    # duplicate categories, which raises.  Strict UTF-8 decoding is injective, so
    # the default path can never collide and must not pay for this scan.
    if encoding_errors != b"strict":
        seen = {}
        remap = np.empty(n_cats, dtype=np.int64)
        remap_view = remap
        for i in range(n_cats):
            remap_view[i] = seen.setdefault(result[i], len(seen))

        if len(seen) != n_cats:
            merged = np.empty(len(seen), dtype=np.object_)
            for label, code in seen.items():
                merged[code] = label
            result = merged
            for i in range(lines):
                if codes[i] != NA:
                    codes[i] = remap_view[codes[i]]

    return np.asarray(codes), result, na_count


# -> ndarray[f'|S{width}']
cdef _to_fw_string(parser_t *parser, int64_t col, int64_t line_start,
                   int64_t line_end, int64_t width):
    cdef:
        char *data
        ndarray result

    result = np.empty(line_end - line_start, dtype=f"|S{width}")
    data = <char*>result.data

    with nogil:
        _to_fw_string_nogil(parser, col, line_start, line_end, width, data)

    return result


cdef void _to_fw_string_nogil(parser_t *parser, int64_t col,
                              int64_t line_start, int64_t line_end,
                              size_t width, char *data) noexcept nogil:
    cdef:
        int64_t _
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        size_t word_len

    coliter_setup(&it, parser, col, line_start)

    for _ in range(line_end - line_start):
        word = coliter_next_with_idx(&it, &token_idx)
        # memcpy at the exact token length rather than strncpy, which stops at
        # an embedded NUL -- numpy "S" dtype can hold one, so truncating there
        # would collapse distinct values.
        word_len = <size_t>_token_len(parser, token_idx)
        if word_len > width:
            word_len = width
        memcpy(data, word, word_len)
        if word_len < width:
            memset(data + word_len, 0, width - word_len)
        data += width


# -> tuple[ndarray[float64_t], int]  | tuple[None, None]
cdef ndarray _wrap_malloc_array(void *data, Py_ssize_t lines, int typenum):
    """
    Wrap nogil-malloc'd memory as a 1D ndarray that owns it (via a capsule
    base). Compared to np.empty this keeps the allocation itself out of the
    GIL-held window, which matters when many parser threads convert columns
    concurrently.
    """
    cdef:
        cnp.npy_intp dims = lines
        ndarray arr

    arr = cnp.PyArray_SimpleNewFromData(1, &dims, typenum, data)
    capsule = PyCapsule_New(data, NULL, _free_malloc_capsule)
    # PyArray_SetBaseObject steals a reference; balance the decref Cython
    # emits when the local goes out of scope.
    Py_INCREF(capsule)
    cnp.PyArray_SetBaseObject(arr, capsule)
    return arr


# The _probe_* helpers parse only the first non-NA token of a column, nogil,
# so a column that will not convert (e.g. strings tried as int) is rejected
# before the result buffer is allocated.
cdef int _probe_int64(parser_t *parser, int64_t col,
                      int64_t line_start, int64_t line_end,
                      bint na_filter,
                      const kh_str_starts_t *na_hashset) noexcept nogil:
    cdef:
        int error = 0
        Py_ssize_t lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        int64_t word_len

    coliter_setup(&it, parser, col, line_start)
    for _ in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        word_len = _token_len(parser, token_idx)
        if na_filter and kh_get_str_starts_item(na_hashset, word,
                                                <size_t>word_len):
            continue
        str_to_int64(word, word_len, &error, parser.thousands)
        return error
    return 0


cdef int _probe_double(parser_t *parser, int64_t col,
                       int64_t line_start, int64_t line_end,
                       bint na_filter,
                       kh_str_starts_t *na_hashset) noexcept nogil:
    cdef:
        int error = 0
        Py_ssize_t lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        const char *word_end = NULL
        c_int64_t token_idx = 0
        int64_t word_len
        char *p_end

    coliter_setup(&it, parser, col, line_start)
    for _ in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        word_len = _token_len(parser, token_idx)
        if na_filter and kh_get_str_starts_item(na_hashset, word,
                                                <size_t>word_len):
            continue
        word_end = word + word_len
        parser.double_converter(word, &p_end, parser.decimal,
                                parser.sci, parser.thousands,
                                1, &error, NULL, word_end)
        if error != 0 or p_end == word or p_end != word_end:
            if infinity_sign(word, word_len) != 0:
                return 0
            return 1
        return 0
    return 0


cdef int _probe_bool_flex(parser_t *parser, int64_t col,
                          int64_t line_start, int64_t line_end,
                          bint na_filter,
                          const kh_str_starts_t *na_hashset,
                          const kh_str_starts_t *true_hashset,
                          const kh_str_starts_t *false_hashset) noexcept nogil:
    cdef:
        Py_ssize_t lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        size_t word_len
        uint8_t tmp

    coliter_setup(&it, parser, col, line_start)
    for _ in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        word_len = <size_t>_token_len(parser, token_idx)
        if na_filter and kh_get_str_starts_item(na_hashset, word, word_len):
            continue
        if kh_get_str_starts_item(true_hashset, word, word_len):
            return 0
        if kh_get_str_starts_item(false_hashset, word, word_len):
            return 0
        return to_boolean(word, <int64_t>word_len, &tmp)
    return 0


cdef _try_double(parser_t *parser, int64_t col,
                 int64_t line_start, int64_t line_end,
                 bint na_filter, kh_str_starts_t *na_hashset, set na_fset):
    cdef:
        int error, na_count = 0
        Py_ssize_t lines
        float64_t *data = NULL
        float64_t NA = na_values[np.float64]
        kh_float64_t *na_fhashset
        ndarray[float64_t] result
        bint use_na_flist = len(na_fset) > 0

    lines = line_end - line_start
    na_fhashset = kset_float64_from_set(na_fset)
    with nogil:
        error = _probe_double(parser, col, line_start, line_end,
                              na_filter, na_hashset)
        if error == 0:
            data = <float64_t *>malloc(
                (lines if lines > 0 else 1) * sizeof(float64_t))
    if error == 0:
        if data == NULL:
            kh_destroy_float64(na_fhashset)
            raise MemoryError()
        result = _wrap_malloc_array(data, lines, cnp.NPY_FLOAT64)
        with nogil:
            error = _try_double_nogil(parser, parser.double_converter,
                                      col, line_start, line_end,
                                      na_filter, na_hashset, use_na_flist,
                                      na_fhashset, NA, data, &na_count)

    kh_destroy_float64(na_fhashset)
    if error != 0:
        return None, None
    return result, na_count


cdef int _try_double_nogil(parser_t *parser,
                           float64_t (*double_converter)(
                               const char *, char **, char,
                               char, char, int, int *, int *,
                               const char *) noexcept nogil,
                           int64_t col, int64_t line_start, int64_t line_end,
                           bint na_filter, kh_str_starts_t *na_hashset,
                           bint use_na_flist,
                           const kh_float64_t *na_fhashset,
                           float64_t NA, float64_t *data,
                           int *na_count) nogil:
    cdef:
        int error = 0, inf_sign
        Py_ssize_t _, lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        const char *word_end
        c_int64_t token_idx = 0
        int64_t word_len
        char *p_end
        khiter_t k64
        # try_parse_plain_double covers the default converter with default
        # settings; tokens it rejects (spaces, inf/nan spellings, junk) take
        # the generic converter below for the legacy semantics.
        bint fastpath = (double_converter == precise_xstrtod_wrapper
                         and parser.thousands == b"\0"
                         and (parser.sci == b"e" or parser.sci == b"E"))

    na_count[0] = 0
    coliter_setup(&it, parser, col, line_start)

    if na_filter:
        for _ in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            word_len = _token_len(parser, token_idx)

            if kh_get_str_starts_item(na_hashset, word, <size_t>word_len):
                # in the hash table
                na_count[0] += 1
                data[0] = NA
            else:
                word_end = word + word_len
                if not (fastpath and
                        try_parse_plain_double(word, word_end,
                                               parser.decimal, data) == 0):
                    data[0] = double_converter(word, &p_end, parser.decimal,
                                               parser.sci, parser.thousands,
                                               1, &error, NULL, word_end)
                    if error != 0 or p_end == word or p_end != word_end:
                        error = 0
                        inf_sign = infinity_sign(word, word_len)
                        if inf_sign > 0:
                            data[0] = INF
                        elif inf_sign < 0:
                            data[0] = NEGINF
                        else:
                            return 1
                if use_na_flist:
                    k64 = kh_get_float64(na_fhashset, data[0])
                    if k64 != na_fhashset.n_buckets:
                        na_count[0] += 1
                        data[0] = NA
            data += 1
    else:
        for _ in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            word_end = word + _token_len(parser, token_idx)
            if not (fastpath and
                    try_parse_plain_double(word, word_end,
                                           parser.decimal, data) == 0):
                data[0] = double_converter(word, &p_end, parser.decimal,
                                           parser.sci, parser.thousands,
                                           1, &error, NULL, word_end)
                if error != 0 or p_end == word or p_end != word_end:
                    error = 0
                    inf_sign = infinity_sign(word, word_end - word)
                    if inf_sign > 0:
                        data[0] = INF
                    elif inf_sign < 0:
                        data[0] = NEGINF
                    else:
                        return 1
            data += 1

    return 0


cdef _try_uint64(parser_t *parser, int64_t col,
                 int64_t line_start, int64_t line_end,
                 bint na_filter, kh_str_starts_t *na_hashset,
                 bint raise_on_invalid):
    cdef:
        int error
        Py_ssize_t lines
        coliter_t it
        uint64_t *data
        ndarray[uint64_t] result
        uint_state state

    lines = line_end - line_start
    result = np.empty(lines, dtype=np.uint64)
    data = <uint64_t *>result.data

    uint_state_init(&state)
    coliter_setup(&it, parser, col, line_start)
    with nogil:
        error = _try_uint64_nogil(parser, col, line_start, line_end,
                                  na_filter, na_hashset, data, &state)
    if error != 0:
        if error == ERROR_OVERFLOW:
            # Can't get the word variable
            raise OverflowError("Overflow")
        elif raise_on_invalid and error == ERROR_INVALID_CHARS:
            raise ValueError("Number is not int")
        return None

    if uint64_conflict(&state):
        raise ValueError("Cannot convert to numerical dtype")

    if state.seen_sint:
        raise OverflowError("Overflow")

    return result


cdef inline const char* _parser_word(parser_t *parser,
                                     int64_t idx) noexcept nogil:
    # Pointer to word ``idx`` in the stream (NUL-terminated).
    if idx == 0:
        return parser.stream
    return parser.stream + parser.word_ends[idx - 1] + 1


cdef inline int64_t _token_len(parser_t *parser, int64_t token_idx) noexcept nogil:
    # Length of the token at ``token_idx`` (excluding its trailing NUL),
    # derived from adjacent word_ends entries so we avoid a strlen scan.
    # token_idx == -1 signals a missing field (word == "").
    if token_idx < 0:
        return 0
    elif token_idx == 0:
        return parser.word_ends[0]
    return parser.word_ends[token_idx] - parser.word_ends[token_idx - 1] - 1


cdef int _try_uint64_nogil(parser_t *parser, int64_t col,
                           int64_t line_start,
                           int64_t line_end, bint na_filter,
                           const kh_str_starts_t *na_hashset,
                           uint64_t *data, uint_state *state) nogil:
    cdef:
        int error
        Py_ssize_t i, lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        int64_t word_len
        char thousands = parser.thousands

    coliter_setup(&it, parser, col, line_start)

    if na_filter:
        for i in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            word_len = _token_len(parser, token_idx)
            if kh_get_str_starts_item(na_hashset, word, <size_t>word_len):
                # in the hash table
                state.seen_null = 1
                data[i] = 0
                continue

            data[i] = str_to_uint64(state, word, word_len, &error, thousands)
            if error != 0:
                return error
    else:
        for i in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            data[i] = str_to_uint64(state, word, _token_len(parser, token_idx),
                                    &error, thousands)
            if error != 0:
                return error

    return 0


cdef _try_int64(parser_t *parser, int64_t col,
                int64_t line_start, int64_t line_end,
                bint na_filter, kh_str_starts_t *na_hashset, bint raise_on_invalid):
    cdef:
        int error, na_count = 0
        Py_ssize_t lines
        int64_t *data = NULL
        ndarray[int64_t] result
        int64_t NA = na_values[np.int64]

    lines = line_end - line_start
    with nogil:
        error = _probe_int64(parser, col, line_start, line_end,
                             na_filter, na_hashset)
        if error == 0:
            data = <int64_t *>malloc(
                (lines if lines > 0 else 1) * sizeof(int64_t))
    if error == 0:
        if data == NULL:
            raise MemoryError()
        result = _wrap_malloc_array(data, lines, cnp.NPY_INT64)
        with nogil:
            error = _try_int64_nogil(parser, col, line_start, line_end,
                                     na_filter, na_hashset, NA, data,
                                     &na_count)
    if error != 0:
        if error == ERROR_OVERFLOW:
            # Can't get the word variable
            raise OverflowError("Overflow")
        elif raise_on_invalid and error == ERROR_INVALID_CHARS:
            raise ValueError("Number is not int")
        return None, None

    return result, na_count


cdef int _try_int64_nogil(parser_t *parser, int64_t col,
                          int64_t line_start,
                          int64_t line_end, bint na_filter,
                          const kh_str_starts_t *na_hashset, int64_t NA,
                          int64_t *data, int *na_count) nogil:
    cdef:
        int error
        Py_ssize_t i, lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        int64_t word_len
        char thousands = parser.thousands

    na_count[0] = 0
    coliter_setup(&it, parser, col, line_start)

    if na_filter:
        for i in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            word_len = _token_len(parser, token_idx)
            if kh_get_str_starts_item(na_hashset, word, <size_t>word_len):
                # in the hash table
                na_count[0] += 1
                data[i] = NA
                continue

            data[i] = str_to_int64(word, word_len, &error, thousands)
            if error != 0:
                return error
    else:
        for i in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            data[i] = str_to_int64(word, _token_len(parser, token_idx),
                                   &error, thousands)
            if error != 0:
                return error

    return 0


@cython.wraparound(False)
@cython.boundscheck(False)
cdef _try_pylong(parser_t *parser, Py_ssize_t col,
                 int64_t line_start, int64_t line_end,
                 bint na_filter, kh_str_starts_t *na_hashset):
    cdef:
        int na_count = 0
        Py_ssize_t lines
        coliter_t it
        const char *word = NULL
        char *pend = NULL
        c_int64_t token_idx = 0
        int64_t word_len
        ndarray[object] result
        object NA = na_values[np.object_]

    lines = line_end - line_start
    result = np.empty(lines, dtype=object)
    coliter_setup(&it, parser, col, line_start)

    for i in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        word_len = _token_len(parser, token_idx)
        if na_filter and kh_get_str_starts_item(na_hashset, word,
                                                <size_t>word_len):
            # in the hash table
            na_count += 1
            result[i] = NA
            continue

        # PyLong_FromString is declared returning object, so a parse failure
        # raises rather than returning None.
        py_int = PyLong_FromString(word, &pend, 10)
        # Require the parse to reach the end of the token: PyLong_FromString
        # stops at an embedded NUL, so "1\0xyz" would otherwise be accepted
        # as 1.  The caller turns this ValueError into a string column.
        if <const char*>pend != word + word_len:
            raise ValueError("Invalid integer ", word[:word_len])
        result[i] = py_int

    return result, na_count


# -> tuple[ndarray[bool], int]
cdef _try_bool_flex(parser_t *parser, int64_t col,
                    int64_t line_start, int64_t line_end,
                    bint na_filter, const kh_str_starts_t *na_hashset,
                    const kh_str_starts_t *true_hashset,
                    const kh_str_starts_t *false_hashset):
    cdef:
        int error, na_count = 0
        Py_ssize_t lines
        uint8_t *data = NULL
        ndarray[uint8_t] result
        uint8_t NA = na_values[np.bool_]

    lines = line_end - line_start
    with nogil:
        error = _probe_bool_flex(parser, col, line_start, line_end,
                                 na_filter, na_hashset, true_hashset,
                                 false_hashset)
        if error == 0:
            data = <uint8_t *>malloc(
                (lines if lines > 0 else 1) * sizeof(uint8_t))
    if error == 0:
        if data == NULL:
            raise MemoryError()
        result = _wrap_malloc_array(data, lines, cnp.NPY_UINT8)
        with nogil:
            error = _try_bool_flex_nogil(parser, col, line_start, line_end,
                                         na_filter, na_hashset, true_hashset,
                                         false_hashset, NA, data, &na_count)
    if error != 0:
        return None, None
    return result.view(np.bool_), na_count


cdef int _try_bool_flex_nogil(parser_t *parser, int64_t col,
                              int64_t line_start,
                              int64_t line_end, bint na_filter,
                              const kh_str_starts_t *na_hashset,
                              const kh_str_starts_t *true_hashset,
                              const kh_str_starts_t *false_hashset,
                              uint8_t NA, uint8_t *data,
                              int *na_count) nogil:
    cdef:
        int error = 0
        Py_ssize_t _, lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        size_t word_len

    na_count[0] = 0
    coliter_setup(&it, parser, col, line_start)

    if na_filter:
        for _ in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            word_len = <size_t>_token_len(parser, token_idx)

            if kh_get_str_starts_item(na_hashset, word, word_len):
                # in the hash table
                na_count[0] += 1
                data[0] = NA
                data += 1
                continue

            if kh_get_str_starts_item(true_hashset, word, word_len):
                data[0] = 1
                data += 1
                continue
            if kh_get_str_starts_item(false_hashset, word, word_len):
                data[0] = 0
                data += 1
                continue

            error = to_boolean(word, <int64_t>word_len, data)
            if error != 0:
                return error
            data += 1
    else:
        for _ in range(lines):
            word = coliter_next_with_idx(&it, &token_idx)
            word_len = <size_t>_token_len(parser, token_idx)

            if kh_get_str_starts_item(true_hashset, word, word_len):
                data[0] = 1
                data += 1
                continue

            if kh_get_str_starts_item(false_hashset, word, word_len):
                data[0] = 0
                data += 1
                continue

            error = to_boolean(word, <int64_t>word_len, data)
            if error != 0:
                return error
            data += 1

    return 0


cdef inline int _bool_numeric_literal(const char *word,
                                      int64_t length) noexcept nogil:
    # The numeric boolean spellings BooleanArray accepts by default:
    # "1"/"1.0" -> 1, "0"/"0.0" -> 0, anything else -> -1.  Compare against
    # `length` rather than a NUL so a token like "1\0x" is not read as "1".
    if length == 1:
        if word[0] == ord("1"):
            return 1
        if word[0] == ord("0"):
            return 0
    elif length == 3 and word[1] == ord(".") and word[2] == ord("0"):
        if word[0] == ord("1"):
            return 1
        if word[0] == ord("0"):
            return 0
    return -1


cdef int _try_boolean_masked_nogil(parser_t *parser, int64_t col,
                                   int64_t line_start, int64_t line_end,
                                   bint na_filter,
                                   const kh_str_starts_t *na_hashset,
                                   const kh_str_starts_t *true_hashset,
                                   const kh_str_starts_t *false_hashset,
                                   uint8_t *data, uint8_t *mask) noexcept nogil:
    # Fill data (0/1) and mask (1 == NA) for a nullable "boolean" column,
    # recognizing the true/false hash sets plus the "1"/"1.0"/"0"/"0.0" numeric
    # spellings -- i.e. BooleanArray._from_sequence_of_strings' token set.  The
    # true set is tested before the false set, matching map_string()'s ordering.
    # Returns -1 on the first unrecognized token so the caller falls back to the
    # generic path (which raises the canonical error).
    cdef:
        Py_ssize_t i, lines = line_end - line_start
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        size_t word_len
        int numeric

    coliter_setup(&it, parser, col, line_start)
    for i in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        word_len = <size_t>_token_len(parser, token_idx)

        if na_filter and kh_get_str_starts_item(na_hashset, word, word_len):
            mask[i] = 1
            data[i] = 0
            continue

        numeric = _bool_numeric_literal(word, <int64_t>word_len)
        if kh_get_str_starts_item(true_hashset, word, word_len) or numeric == 1:
            data[i] = 1
        elif kh_get_str_starts_item(false_hashset, word, word_len) or numeric == 0:
            data[i] = 0
        else:
            return -1

    return 0


cdef kh_str_starts_t* kset_from_list(list values) except NULL:
    # caller takes responsibility for freeing the hash table
    cdef:
        Py_ssize_t i
        kh_str_starts_t *table
        int ret = 0
        object val
        char *buf
        Py_ssize_t buflen

    table = kh_init_str_starts()

    for i in range(len(values)):
        val = values[i]

        # None creeps in sometimes, which isn't possible here
        if not isinstance(val, bytes):
            kh_destroy_str_starts(table)
            raise ValueError("Must be all encoded bytes")

        # PyBytes_AsStringAndSize, not PyBytes_AsString: an na_value may itself
        # contain an embedded NUL, and its length is what makes it comparable.
        PyBytes_AsStringAndSize(val, &buf, &buflen)
        kh_put_str_starts_item(table, buf, <size_t>buflen, &ret)

    if table.table.n_buckets <= 128:
        # Resize the hash table to make it almost empty, this
        # reduces amount of hash collisions on lookup thus
        # "key not in table" case is faster.
        # Note that this trades table memory footprint for lookup speed.
        kh_resize_str_starts(table, table.table.n_buckets * 8)

    return table


cdef kh_float64_t* kset_float64_from_set(set values) except NULL:
    # caller takes responsibility for freeing the hash table
    cdef:
        kh_float64_t *table
        int ret = 0
        float64_t val
        object value

    table = kh_init_float64()

    for value in values:
        val = float(value)

        kh_put_float64(table, val, &ret)

    if table.n_buckets <= 128:
        # See reasoning in kset_from_list
        kh_resize_float64(table, table.n_buckets * 8)
    return table


cdef raise_parser_error(object base, parser_t *parser):
    cdef:
        object old_exc
        object exc_type
        PyObject *type
        PyObject *value
        PyObject *traceback

    if PyErr_Occurred():
        PyErr_Fetch(&type, &value, &traceback)
        Py_XDECREF(traceback)

        if value != NULL:
            old_exc = <object>value
            Py_XDECREF(value)

            # PyErr_Fetch only returned the error message in *value,
            # so the Exception class must be extracted from *type.
            if isinstance(old_exc, str):
                if type != NULL:
                    exc_type = <object>type
                else:
                    exc_type = ParserError

                Py_XDECREF(type)
                raise exc_type(old_exc)
            else:
                Py_XDECREF(type)
                raise old_exc

    message = f"{base}. C error: "
    if parser.error_msg != NULL:
        message += parser.error_msg.decode("utf-8")
    else:
        message += "no error message set"

    raise ParserError(message)


# ----------------------------------------------------------------------
# NA values
def _compute_na_values():
    int64info = np.iinfo(np.int64)
    int32info = np.iinfo(np.int32)
    int16info = np.iinfo(np.int16)
    int8info = np.iinfo(np.int8)
    uint64info = np.iinfo(np.uint64)
    uint32info = np.iinfo(np.uint32)
    uint16info = np.iinfo(np.uint16)
    uint8info = np.iinfo(np.uint8)
    na_values = {
        np.float32: np.nan,
        np.float64: np.nan,
        np.complex64: np.nan,
        np.complex128: np.nan,
        np.int64: int64info.min,
        np.int32: int32info.min,
        np.int16: int16info.min,
        np.int8: int8info.min,
        np.uint64: uint64info.max,
        np.uint32: uint32info.max,
        np.uint16: uint16info.max,
        np.uint8: uint8info.max,
        np.bool_: uint8info.max,
        np.object_: np.nan,
    }
    return na_values


na_values = _compute_na_values()

for k in list(na_values):
    na_values[np.dtype(k)] = na_values[k]


# -> ArrayLike
@cython.wraparound(False)
@cython.boundscheck(False)
cdef _apply_converter(object f, parser_t *parser, int64_t col,
                      int64_t line_start, int64_t line_end):
    cdef:
        Py_ssize_t i, lines
        coliter_t it
        const char *word = NULL
        c_int64_t token_idx = 0
        ndarray[object] result
        object val

    lines = line_end - line_start
    result = np.empty(lines, dtype=np.object_)

    coliter_setup(&it, parser, col, line_start)

    for i in range(lines):
        word = coliter_next_with_idx(&it, &token_idx)
        # _token_len, not PyUnicode_FromString: a converter must see the same
        # value the object path produces, embedded NULs included.
        val = PyUnicode_DecodeUTF8(word, _token_len(parser, token_idx), NULL)
        result[i] = f(val)

    return lib.maybe_convert_objects(result)


cdef list _maybe_encode(list values):
    if values is None:
        return []
    return [x.encode("utf-8") if isinstance(x, str) else x for x in values]


@cython.wraparound(False)
@cython.boundscheck(False)
def sanitize_objects(ndarray[object] values, set na_values) -> int:
    """
    Convert specified values, including the given set na_values to np.nan.

    Parameters
    ----------
    values : ndarray[object]
    na_values : set

    Returns
    -------
    na_count : int
    """
    cdef:
        Py_ssize_t i, n
        object val, onan
        Py_ssize_t na_count = 0
        dict memo = {}

    n = len(values)
    onan = np.nan
    bool_set = {True, False}

    for i in range(n):
        val = values[i]
        if val in na_values:
            values[i] = onan
            na_count += 1
        elif val in bool_set:
            # GH60088: Skip memoization
            # since 1 == 1.0 == True == np.True_
            # and 0 == 0.0 == False == np.False_
            values[i] = val
        elif val in memo:
            values[i] = memo[val]
        else:
            memo[val] = val

    return na_count
